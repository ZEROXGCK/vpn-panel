'use strict';
const express      = require('express');
const https        = require('https');
const http         = require('http');
const fs           = require('fs');
const path         = require('path');
const crypto       = require('crypto');
const jwt          = require('jsonwebtoken');
const axios        = require('axios');
const cors         = require('cors');
const { WebSocketServer } = require('ws');
const si           = require('systeminformation');
const rateLimit    = require('express-rate-limit');
const { exec, execSync } = require('child_process');
const { v4: uuidv4 } = require('uuid');
const cron         = require('node-cron');

// ─── CONFIG ────────────────────────────────────────────────
const CFG_PATH = '/opt/vpn-panel/config/panel.json';
const USERS_PATH = '/opt/vpn-panel/config/users.json';
const CLIENTS_DIR = '/opt/vpn-panel/clients';
const OVPN_EASY = '/etc/openvpn/easy-rsa';

if (!fs.existsSync(CFG_PATH)) {
  console.error('[FATAL] Config not found:', CFG_PATH);
  process.exit(1);
}
const C = JSON.parse(fs.readFileSync(CFG_PATH, 'utf8'));

// ─── HELPERS ───────────────────────────────────────────────
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const loadUsers = () => {
  if (!fs.existsSync(USERS_PATH)) { fs.writeFileSync(USERS_PATH,'[]'); return []; }
  try { return JSON.parse(fs.readFileSync(USERS_PATH,'utf8')); } catch { return []; }
};
const saveUsers = (u) => fs.writeFileSync(USERS_PATH, JSON.stringify(u,null,2));
const shellSafe = (s) => /^[a-zA-Z0-9_\-\.]+$/.test(s);
const run = (cmd, opts={}) => new Promise((res,rej) =>
  exec(cmd, { timeout:60000, ...opts }, (e,o,r) => e ? rej(new Error(r||e.message)) : res(o.trim()))
);

// Cache for 3x-ui session cookie
let xrayCookie = '';
let xrayCookieTime = 0;

async function getXrayCookie() {
  if (xrayCookie && Date.now() - xrayCookieTime < 3600000) return xrayCookie;
  try {
    const r = await axios.post(`http://127.0.0.1:${C.xray.port}/login`,
      `username=${C.xray.username}&password=${C.xray.password}`,
      { headers:{'Content-Type':'application/x-www-form-urlencoded'}, timeout:5000, maxRedirects:0, validateStatus:s=>s<400 }
    );
    const setCookie = r.headers['set-cookie'];
    if (setCookie) {
      xrayCookie = setCookie.map(c=>c.split(';')[0]).join('; ');
      xrayCookieTime = Date.now();
    }
  } catch {}
  return xrayCookie;
}

// ─── APP ───────────────────────────────────────────────────
const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit:'10mb' }));
app.use(express.urlencoded({ extended:true }));
app.use(express.static(path.join(__dirname,'public'), { maxAge:'1h' }));

const limiter = rateLimit({ windowMs:15*60*1000, max:300, standardHeaders:true, legacyHeaders:false });
const loginLimiter = rateLimit({ windowMs:15*60*1000, max:20 });
app.use('/api/', limiter);

// ─── AUTH MIDDLEWARE ────────────────────────────────────────
const auth = (req, res, next) => {
  const hdr = req.headers.authorization;
  if (!hdr?.startsWith('Bearer ')) return res.status(401).json({ error:'ไม่มี Token' });
  try {
    req.user = jwt.verify(hdr.slice(7), C.admin.jwt_secret);
    next();
  } catch { res.status(401).json({ error:'Token ไม่ถูกต้อง หรือหมดอายุ' }); }
};

// ═══════════════════════════════════════════════════════════
//  AUTH ROUTES
// ═══════════════════════════════════════════════════════════
app.post('/api/login', loginLimiter, (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error:'กรุณากรอกข้อมูลให้ครบ' });
  if (username === C.admin.username && sha256(password) === C.admin.password_hash) {
    const token = jwt.sign({ username, role:'admin', iat:Math.floor(Date.now()/1000) },
      C.admin.jwt_secret, { expiresIn:'24h' });
    return res.json({ token, username, expiresIn:'24h' });
  }
  res.status(401).json({ error:'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
});

app.post('/api/change-password', auth, (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) return res.status(400).json({ error:'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร' });
  C.admin.password_hash = sha256(newPassword);
  fs.writeFileSync(CFG_PATH, JSON.stringify(C,null,2));
  res.json({ success:true });
});

// ═══════════════════════════════════════════════════════════
//  SYSTEM INFO
// ═══════════════════════════════════════════════════════════
app.get('/api/system', auth, async (req, res) => {
  try {
    const [cpu, mem, disk, nets, osI, temp] = await Promise.all([
      si.currentLoad(), si.mem(), si.fsSize(), si.networkStats(), si.osInfo(), si.cpuTemperature()
    ]);
    const mainDisk = disk.filter(d => d.mount === '/' || d.mount === 'C:')[0] || disk[0] || {};
    res.json({
      cpu: {
        usage: parseFloat(cpu.currentLoad.toFixed(1)),
        cores: cpu.cpus?.length || 1,
        temp: temp.main || null
      },
      memory: {
        total: mem.total, used: mem.used, free: mem.free,
        cached: mem.cached, buffers: mem.buffers,
        percent: parseFloat(((mem.used/mem.total)*100).toFixed(1))
      },
      disk: disk.slice(0,4).map(d=>({ fs:d.fs, mount:d.mount, size:d.size, used:d.used, use:d.use })),
      mainDisk: {
        size: mainDisk.size, used: mainDisk.used,
        free: (mainDisk.size - mainDisk.used),
        percent: mainDisk.use
      },
      network: {
        iface: nets[0]?.iface || 'eth0',
        rx_sec: nets[0]?.rx_sec || 0,
        tx_sec: nets[0]?.tx_sec || 0,
        rx_bytes: nets[0]?.rx_bytes || 0,
        tx_bytes: nets[0]?.tx_bytes || 0
      },
      os: { distro:osI.distro, release:osI.release, kernel:osI.kernel, hostname:osI.hostname, arch:osI.arch },
      uptime: osI.uptime
    });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ─── Network traffic history ────────────────────────────────
const netHistory = { rx:[], tx:[], time:[] };
cron.schedule('* * * * * *', async () => {
  try {
    const nets = await si.networkStats();
    const now = Date.now();
    netHistory.rx.push(nets[0]?.rx_sec||0);
    netHistory.tx.push(nets[0]?.tx_sec||0);
    netHistory.time.push(now);
    if (netHistory.rx.length > 60) { netHistory.rx.shift(); netHistory.tx.shift(); netHistory.time.shift(); }
  } catch {}
});

app.get('/api/system/network-history', auth, (req, res) => res.json(netHistory));

// ═══════════════════════════════════════════════════════════
//  SPEED TEST
// ═══════════════════════════════════════════════════════════
app.post('/api/speedtest', auth, (req, res) => {
  res.setHeader('Content-Type','text/event-stream');
  res.setHeader('Cache-Control','no-cache');
  res.setHeader('Connection','keep-alive');
  res.setHeader('X-Accel-Buffering','no');
  const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

  send({ stage:'start', message:'เริ่มทดสอบความเร็ว...' });

  // Try speedtest-cli first
  const proc = exec('speedtest-cli --json --secure 2>/dev/null', { timeout:90000 }, (err, stdout) => {
    if (!err && stdout) {
      try {
        const r = JSON.parse(stdout);
        send({
          stage:'done',
          download: parseFloat((r.download/1e6).toFixed(2)),
          upload: parseFloat((r.upload/1e6).toFixed(2)),
          ping: parseFloat(r.ping.toFixed(1)),
          server: r.server?.name || 'Speedtest.net',
          ip: r.client?.ip || '',
          isp: r.client?.isp || '',
          method: 'speedtest-cli'
        });
        return res.end();
      } catch {}
    }

    // Fallback: Cloudflare
    send({ stage:'progress', message:'ใช้ Cloudflare speed test...' });
    const dl_start = Date.now();
    exec('curl -o /dev/null -s -w "%{speed_download}" --max-time 20 "https://speed.cloudflare.com/__down?bytes=25000000"',
      { timeout:25000 }, (e2, dlOut) => {
        const dlBps = parseFloat(dlOut)||0;
        const dlMbps = parseFloat((dlBps*8/1e6).toFixed(2));
        send({ stage:'progress', message:'ทดสอบ Upload...', download:dlMbps });

        exec('curl -o /dev/null -s -w "%{speed_upload}" --max-time 20 -X POST -d @/dev/urandom "https://speed.cloudflare.com/__up" --data-binary @<(dd if=/dev/urandom bs=1M count=10 2>/dev/null)',
          { timeout:25000, shell:'/bin/bash' }, (e3, ulOut) => {
            const ulBps = parseFloat(ulOut)||0;
            const ulMbps = parseFloat((ulBps*8/1e6).toFixed(2));

            exec('ping -c 4 -W 2 1.1.1.1 2>/dev/null | tail -1 | awk -F"/" \'{print $5}\'', {timeout:10000}, (e4,pingOut) => {
              send({
                stage:'done',
                download: dlMbps,
                upload: ulMbps||0,
                ping: parseFloat(pingOut)||0,
                server:'Cloudflare (1.1.1.1)',
                ip:'',
                method:'cloudflare'
              });
              res.end();
            });
          });
      });
  });

  req.on('close', () => proc.kill && proc.kill());
});

// Multi-target ping test
app.get('/api/ping-test', auth, (req, res) => {
  const targets = [
    { host:'8.8.8.8',  name:'Google DNS' },
    { host:'1.1.1.1',  name:'Cloudflare' },
    { host:'9.9.9.9',  name:'Quad9' },
    { host:'208.67.222.222', name:'OpenDNS' },
  ];
  const results = [];
  let done = 0;
  targets.forEach(t => {
    exec(`ping -c 4 -W 3 ${t.host} 2>/dev/null | tail -1 | awk -F'/' '{print $5}'`, {timeout:15000}, (e,out) => {
      results.push({ ...t, ms: parseFloat(out)||null, error: e?true:false });
      if (++done === targets.length) res.json(results);
    });
  });
});

// ═══════════════════════════════════════════════════════════
//  USERS (SSH / OpenVPN)
// ═══════════════════════════════════════════════════════════
app.get('/api/users', auth, (req, res) => {
  const users = loadUsers();
  const { type } = req.query;
  res.json(type ? users.filter(u=>u.type===type) : users);
});

app.get('/api/users/stats', auth, (req, res) => {
  const users = loadUsers();
  const now = new Date();
  res.json({
    total: users.length,
    active: users.filter(u => new Date(u.expires) > now).length,
    expired: users.filter(u => new Date(u.expires) <= now).length,
    ssh: users.filter(u=>u.type==='ssh').length,
    openvpn: users.filter(u=>u.type==='openvpn').length
  });
});

// ─── CREATE SSH USER ────────────────────────────────────────
app.post('/api/users/ssh', auth, async (req, res) => {
  let { username, password, days, quota, limit_conn } = req.body;
  if (!username) return res.status(400).json({ error:'กรุณากรอกชื่อผู้ใช้' });
  if (!shellSafe(username)) return res.status(400).json({ error:'ชื่อผู้ใช้ไม่ถูกต้อง (a-z, A-Z, 0-9, _, - เท่านั้น)' });
  if (!password || !password.trim()) password = crypto.randomBytes(8).toString('base64').replace(/[+/=]/g,'').slice(0,12);
  days = parseInt(days)||30;
  const expireDate = new Date(); expireDate.setDate(expireDate.getDate()+days);
  const expireStr  = expireDate.toISOString().split('T')[0].replace(/-/g,'');

  try {
    await run(`id ${username} 2>/dev/null || useradd -M -s /bin/false -e ${expireStr} ${username}`);
    await run(`echo "${username}:${password.replace(/"/g,'\\"')}" | chpasswd`);
    await run(`chage -E ${expireDate.toISOString().split('T')[0]} ${username}`);
  } catch(e) { return res.status(500).json({ error: e.message }); }

  const user = {
    id: uuidv4(), type:'ssh', username, password,
    created: new Date().toISOString(), expires: expireDate.toISOString(),
    days, quota: quota||'unlimited', limit_conn: limit_conn||2, active:true
  };
  const users = loadUsers(); users.push(user); saveUsers(users);

  res.json({
    success:true, user,
    connection:{
      host: C.server.ip, port:22,
      username, password,
      expires: expireDate.toLocaleDateString('th-TH'),
      ws_url: `ws://${C.server.ip}:8880`,
      ws_port: 8880,
      udp_port: 7300
    }
  });
});

// ─── RENEW SSH ──────────────────────────────────────────────
app.put('/api/users/ssh/:id/renew', auth, async (req, res) => {
  const { days } = req.body;
  const users = loadUsers();
  const u = users.find(x=>x.id===req.params.id);
  if (!u) return res.status(404).json({ error:'ไม่พบผู้ใช้' });
  const d = parseInt(days)||30;
  const newExp = new Date(); newExp.setDate(newExp.getDate()+d);
  u.expires = newExp.toISOString(); u.days = d;
  try {
    await run(`chage -E ${newExp.toISOString().split('T')[0]} ${u.username}`);
  } catch {}
  saveUsers(users);
  res.json({ success:true, expires: newExp.toISOString() });
});

// ─── CREATE OPENVPN CLIENT ──────────────────────────────────
// รองรับ 4 โหมด: udp, tcp, ws (WebSocket), ssl (stunnel)
app.post('/api/users/openvpn', auth, async (req, res) => {
  let { username, days, password, mode } = req.body;
  // mode: 'all' | 'udp' | 'tcp' | 'ws' | 'ssl'  (default = all)
  if (!username) return res.status(400).json({ error:'กรุณากรอกชื่อ Client' });
  if (!shellSafe(username)) return res.status(400).json({ error:'ชื่อไม่ถูกต้อง (a-z, 0-9, _ เท่านั้น)' });
  if (!fs.existsSync(`${OVPN_EASY}/pki`)) return res.status(500).json({ error:'OpenVPN ยังไม่ได้ติดตั้ง' });

  // สร้าง cert
  try {
    await run(`cd ${OVPN_EASY} && ./easyrsa --batch gen-req ${username} nopass`, { shell:'/bin/bash' });
    await run(`cd ${OVPN_EASY} && ./easyrsa --batch sign-req client ${username}`, { shell:'/bin/bash' });
  } catch(e) { return res.status(500).json({ error:'สร้าง Certificate ไม่สำเร็จ: '+e.message }); }

  // ถ้ามี password → บันทึกลง users.db สำหรับ auth-user-pass
  const USERS_DB = '/etc/openvpn/auth/users.db';
  let hasUserPass = false;
  if (password && password.trim()) {
    const hash = require('crypto').createHash('sha256').update(password).digest('hex');
    try {
      // ลบ entry เก่าถ้ามี แล้วเพิ่มใหม่
      await run(`sed -i '/^${username}:/d' ${USERS_DB} 2>/dev/null; echo "${username}:${hash}" >> ${USERS_DB}`);
      hasUserPass = true;
    } catch {}
  }

  try {
    const ip  = C.server.ip;
    const ca  = fs.readFileSync('/etc/openvpn/ca.crt','utf8').trim();
    const certRaw = fs.readFileSync(`${OVPN_EASY}/pki/issued/${username}.crt`,'utf8');
    const certMatch = certRaw.match(/-----BEGIN CERTIFICATE-----[\s\S]+?-----END CERTIFICATE-----/);
    const cert = certMatch ? certMatch[0] : certRaw;
    const key  = fs.readFileSync(`${OVPN_EASY}/pki/private/${username}.key`,'utf8').trim();
    const ta   = fs.existsSync('/etc/openvpn/ta.key') ? fs.readFileSync('/etc/openvpn/ta.key','utf8').trim() : '';
    const taBlock = ta ? `<tls-auth>\n${ta}\n</tls-auth>\nkey-direction 1` : '';
    const credBlock = hasUserPass ? `auth-user-pass\n` : '';

    const certBlock = `<ca>\n${ca}\n</ca>\n<cert>\n${cert}\n</cert>\n<key>\n${key}\n</key>\n${taBlock}`;
    const header = `# VPN Panel — ${username}\n# สร้างเมื่อ: ${new Date().toLocaleString('th-TH')}\n`;
    const baseOpts = `remote-cert-tls server\ncipher AES-256-GCM\nauth SHA256\ncompress lz4-v2\npersist-key\npersist-tun\nresolv-retry infinite\nnobind\nverb 3\n`;

    // ── 4 ไฟล์ config แยกตาม mode ─────────────────────────────
    const configs = {
      // UDP (ตรง)
      udp: `${header}client\ndev tun\nproto udp\nremote ${ip} 1194\n${baseOpts}${credBlock}${certBlock}\n`,

      // TCP (ตรง)
      tcp: `${header}client\ndev tun\nproto tcp\nremote ${ip} 1195\n${baseOpts}${credBlock}${certBlock}\n`,

      // WebSocket — ต้องใช้ socks-proxy ผ่าน WebSocket
      // Client connect ไป ws://IP:2086 แล้ว OpenVPN ผ่าน http-proxy
      ws: `${header}# Mode: WebSocket (port 2086)\n# ใช้กับ HTTP Injector / HTTP Custom\nclient\ndev tun\nproto tcp\nremote ${ip} 2086\nhttp-proxy ${ip} 2086\n${baseOpts}${credBlock}${certBlock}\n`,

      // SSL/stunnel — connect ผ่าน stunnel port 2087
      ssl: `${header}# Mode: SSL/TLS (stunnel port 2087)\nclient\ndev tun\nproto tcp\nremote ${ip} 2087\n${baseOpts}${credBlock}${certBlock}\n`,
    };

    if (!fs.existsSync(CLIENTS_DIR)) fs.mkdirSync(CLIENTS_DIR, { recursive:true });

    const files = [];
    const modesToCreate = (!mode || mode === 'all') ? ['udp','tcp','ws','ssl'] : [mode];

    for (const m of modesToCreate) {
      if (!configs[m]) continue;
      const fname = `${username}-${m}.ovpn`;
      fs.writeFileSync(`${CLIENTS_DIR}/${fname}`, configs[m]);
      files.push({ mode:m, filename:fname, downloadUrl:`/api/users/openvpn/download/${fname}` });
    }

    // default .ovpn = udp
    const defaultOvpn = `${username}.ovpn`;
    fs.writeFileSync(`${CLIENTS_DIR}/${defaultOvpn}`, configs.udp);

    const expDate = new Date(); expDate.setDate(expDate.getDate()+(parseInt(days)||30));
    const users = loadUsers();
    // ลบ entry เก่าถ้าชื่อซ้ำ
    const filtered = users.filter(u => !(u.type==='openvpn' && u.username===username));
    filtered.push({
      id:uuidv4(), type:'openvpn', username,
      password: hasUserPass ? password : '',
      hasUserPass,
      created:new Date().toISOString(), expires:expDate.toISOString(),
      days:parseInt(days)||30,
      configFile:defaultOvpn,
      modes: modesToCreate,
      active:true
    });
    saveUsers(filtered);

    res.json({
      success:true,
      files,
      downloadUrl:`/api/users/openvpn/download/${defaultOvpn}`,
      filename: defaultOvpn,
      hasUserPass,
      modes: modesToCreate
    });
  } catch(e) { res.status(500).json({ error:'สร้าง .ovpn ไม่สำเร็จ: '+e.message }); }
});

// ─── DOWNLOAD OVPN FILE ──────────────────────────────────────
app.get('/api/users/openvpn/download/:filename', auth, (req, res) => {
  const { filename } = req.params;
  // allow username.ovpn and username-mode.ovpn
  if (!/^[a-zA-Z0-9_\-]+\.ovpn$/.test(filename)) return res.status(400).json({ error:'Invalid filename' });
  const file = `${CLIENTS_DIR}/${filename}`;
  if (!fs.existsSync(file)) return res.status(404).json({ error:'ไม่พบไฟล์' });
  res.download(file, filename);
});

// ─── LIST AVAILABLE OVPN MODES ──────────────────────────────
app.get('/api/users/openvpn/modes', auth, (req, res) => {
  res.json({
    modes: [
      { id:'all', label:'ทั้งหมด 4 ไฟล์', desc:'UDP + TCP + WS + SSL' },
      { id:'udp', label:'UDP (port 1194)', desc:'เร็วสุด ปกติสุด' },
      { id:'tcp', label:'TCP (port 1195)', desc:'เสถียรกว่า UDP' },
      { id:'ws',  label:'WebSocket (port 2086)', desc:'HTTP Injector, HTTP Custom, Nexus' },
      { id:'ssl', label:'SSL/stunnel (port 2087)', desc:'ผ่าน stunnel, bypass firewall' },
    ],
    ports: { udp:1194, tcp:1195, ws:2086, ssl:2087 }
  });
});

// ─── DELETE USER ─────────────────────────────────────────────
// ─── RENEW ANY USER (SSH or OpenVPN) ────────────────────────
app.put('/api/users/:id/renew', auth, async (req, res) => {
  const { days } = req.body;
  const users = loadUsers();
  const u = users.find(x => x.id === req.params.id);
  if (!u) return res.status(404).json({ error: 'ไม่พบผู้ใช้' });
  const d = parseInt(days) || 30;
  const newExp = new Date();
  newExp.setDate(newExp.getDate() + d);
  u.expires = newExp.toISOString();
  u.days = d;
  if (u.type === 'ssh') {
    try { await run(`chage -E ${newExp.toISOString().split('T')[0]} ${u.username}`); } catch {}
  }
  saveUsers(users);
  res.json({ success: true, expires: newExp.toISOString(), days: d });
});

// ─── UPDATE USER (change password, quota, limit) ─────────────
app.put('/api/users/:id', auth, async (req, res) => {
  const { password, quota, limit_conn } = req.body;
  const users = loadUsers();
  const u = users.find(x => x.id === req.params.id);
  if (!u) return res.status(404).json({ error: 'ไม่พบผู้ใช้' });
  if (password) {
    u.password = password;
    if (u.type === 'ssh') {
      try { await run(`echo "${u.username}:${password.replace(/"/g, '\\"')}" | chpasswd`); } catch {}
    }
  }
  if (quota !== undefined) u.quota = quota;
  if (limit_conn !== undefined) u.limit_conn = parseInt(limit_conn);
  saveUsers(users);
  res.json({ success: true, user: u });
});

app.delete('/api/users/:id', auth, async (req, res) => {
  const users = loadUsers();
  const idx = users.findIndex(u=>u.id===req.params.id);
  if (idx===-1) return res.status(404).json({ error:'ไม่พบผู้ใช้' });
  const u = users[idx];
  if (u.type==='ssh') {
    try { await run(`pkill -u ${u.username} 2>/dev/null; userdel ${u.username} 2>/dev/null`); } catch {}
  }
  if (u.type==='openvpn') {
    try {
      await run(`cd ${OVPN_EASY} && ./easyrsa --batch revoke ${u.username} && ./easyrsa --batch gen-crl`, {shell:'/bin/bash'});
      const f = `${CLIENTS_DIR}/${u.username}.ovpn`;
      if (fs.existsSync(f)) fs.unlinkSync(f);
    } catch {}
  }
  users.splice(idx,1); saveUsers(users);
  res.json({ success:true });
});

// ─── ONLINE USERS ────────────────────────────────────────────
app.get('/api/users/online', auth, (req, res) => {
  exec('who -u 2>/dev/null', (e,out) => {
    const lines = (out||'').split('\n').filter(Boolean).map(l => {
      const p = l.trim().split(/\s+/);
      return { user:p[0], tty:p[1], date:p[2]+' '+p[3], pid:p[5], host:p[6]||'' };
    });
    // Also check openvpn
    exec('cat /var/log/openvpn/status.log 2>/dev/null | grep "^CLIENT_LIST"', (e2,out2) => {
      const ovpnUsers = (out2||'').split('\n').filter(l=>l.startsWith('CLIENT_LIST')).map(l => {
        const p = l.split(',');
        return { user:p[1], real_addr:p[2], virt_addr:p[3], connected_since:p[7], type:'openvpn' };
      });
      res.json({ ssh:lines, openvpn:ovpnUsers });
    });
  });
});

// ═══════════════════════════════════════════════════════════
//  3x-ui / XRAY PROXY
// ═══════════════════════════════════════════════════════════
app.get('/api/xray/status', auth, async (req, res) => {
  try {
    const cookie = await getXrayCookie();
    const r = await axios.get(`http://127.0.0.1:${C.xray.port}/xui/API/inbounds`,
      { headers:{Cookie:cookie}, timeout:5000 });
    res.json({ connected:true, data:r.data });
  } catch(e) {
    res.json({ connected:false, error:e.message, url:`http://127.0.0.1:${C.xray.port}` });
  }
});

app.get('/api/xray/inbounds', auth, async (req, res) => {
  try {
    const cookie = await getXrayCookie();
    const r = await axios.get(`http://127.0.0.1:${C.xray.port}/xui/API/inbounds`,
      { headers:{Cookie:cookie}, timeout:5000 });
    res.json(r.data);
  } catch(e) {
    res.json({ success:false, msg:'ไม่สามารถเชื่อมต่อ 3x-ui: '+e.message, obj:[] });
  }
});

app.post('/api/xray/inbounds', auth, async (req, res) => {
  try {
    const cookie = await getXrayCookie();
    const r = await axios.post(`http://127.0.0.1:${C.xray.port}/xui/API/inbounds/add`,
      req.body, { headers:{Cookie:cookie,'Content-Type':'application/json'}, timeout:5000 });
    res.json(r.data);
  } catch(e) { res.status(500).json({ success:false, msg:e.message }); }
});

app.delete('/api/xray/inbounds/:id', auth, async (req, res) => {
  try {
    const cookie = await getXrayCookie();
    const r = await axios.post(`http://127.0.0.1:${C.xray.port}/xui/API/inbounds/del/${req.params.id}`,
      {}, { headers:{Cookie:cookie}, timeout:5000 });
    res.json(r.data);
  } catch(e) { res.status(500).json({ success:false, msg:e.message }); }
});

// xray client traffic stats
app.get('/api/xray/traffic', auth, async (req, res) => {
  try {
    const cookie = await getXrayCookie();
    const r = await axios.get(`http://127.0.0.1:${C.xray.port}/xui/API/inbounds`,
      { headers:{Cookie:cookie}, timeout:5000 });
    const inbounds = r.data?.obj || [];
    const stats = inbounds.map(ib => ({
      id:ib.id, remark:ib.remark, protocol:ib.protocol, port:ib.port,
      up:ib.up, down:ib.down, total:ib.total, enable:ib.enable,
      clientStats: ib.clientStats || []
    }));
    res.json({ success:true, stats });
  } catch(e) { res.json({ success:false, stats:[] }); }
});

// ═══════════════════════════════════════════════════════════
//  SERVICES MANAGEMENT
// ═══════════════════════════════════════════════════════════
const SERVICES_MAP = {
  'vpn-panel':      { display:'VPN Panel',     icon:'🛡️' },
  'ssh':            { display:'SSH Server',    icon:'🔑' },
  'ws-ssh':         { display:'WebSocket SSH', icon:'🌐' },
  'openvpn@server': { display:'OpenVPN',       icon:'🔒' },
  'x-ui':           { display:'3x-ui (Xray)',  icon:'⚡' },
  'udpgw':          { display:'UDP Gateway',   icon:'📡' },
  'ufw':            { display:'Firewall',      icon:'🔥' },
  'fail2ban':       { display:'Fail2ban',      icon:'🛡' },
};

app.get('/api/services', auth, async (req, res) => {
  const checks = Object.entries(SERVICES_MAP).map(([svc,info]) =>
    new Promise(resolve => {
      exec(`systemctl is-active ${svc} 2>/dev/null`, (e,o) => {
        const status = o.trim();
        exec(`systemctl is-enabled ${svc} 2>/dev/null`, (e2,o2) => {
          resolve({
            service: svc,
            name: info.display,
            icon: info.icon,
            status: status === 'active' ? 'running' : status,
            enabled: o2.trim() === 'enabled',
            active: status === 'active'
          });
        });
      });
    })
  );
  res.json(await Promise.all(checks));
});

app.post('/api/services/:svc/start', auth, async (req, res) => {
  if (!SERVICES_MAP[req.params.svc]) return res.status(400).json({ error:'Service ไม่ถูกต้อง' });
  try { await run(`systemctl start ${req.params.svc}`); res.json({ success:true, action:'start' }); }
  catch(e) { res.status(500).json({ error:e.message }); }
});

app.post('/api/services/:svc/stop', auth, async (req, res) => {
  if (req.params.svc === 'vpn-panel') return res.status(400).json({ error:'ไม่สามารถหยุด Panel ได้' });
  if (!SERVICES_MAP[req.params.svc]) return res.status(400).json({ error:'Service ไม่ถูกต้อง' });
  try { await run(`systemctl stop ${req.params.svc}`); res.json({ success:true, action:'stop' }); }
  catch(e) { res.status(500).json({ error:e.message }); }
});

app.post('/api/services/:svc/restart', auth, async (req, res) => {
  if (!SERVICES_MAP[req.params.svc]) return res.status(400).json({ error:'Service ไม่ถูกต้อง' });
  try { await run(`systemctl restart ${req.params.svc}`); res.json({ success:true, action:'restart' }); }
  catch(e) { res.status(500).json({ error:e.message }); }
});

// ═══════════════════════════════════════════════════════════
//  LOGS
// ═══════════════════════════════════════════════════════════
const LOG_FILES = {
  panel:   '/var/log/vpn-panel.log',
  install: '/var/log/vpn-panel-install.log',
  openvpn: '/var/log/openvpn/openvpn.log',
  syslog:  '/var/log/syslog',
  auth:    '/var/log/auth.log',
  ufw:     '/var/log/ufw.log',
  fail2ban:'/var/log/fail2ban.log'
};

app.get('/api/logs/:source', auth, (req, res) => {
  const file = LOG_FILES[req.params.source];
  if (!file) return res.status(400).json({ error:'ไม่รู้จัก log source' });
  const lines = parseInt(req.query.lines)||100;
  if (!fs.existsSync(file)) return res.json({ lines:[], error:'ไม่พบไฟล์ log' });
  exec(`tail -${lines} "${file}" 2>/dev/null`, (e,out) => {
    res.json({ source:req.params.source, lines:(out||'').split('\n').filter(Boolean) });
  });
});

// Live log stream (SSE)
app.get('/api/logs/:source/stream', auth, (req, res) => {
  const file = LOG_FILES[req.params.source];
  if (!file || !fs.existsSync(file)) return res.status(404).end();
  res.setHeader('Content-Type','text/event-stream');
  res.setHeader('Cache-Control','no-cache');
  res.setHeader('Connection','keep-alive');

  const proc = exec(`tail -f "${file}"`, { timeout:0 });
  proc.stdout.on('data', d => res.write(`data: ${JSON.stringify({ line:d.toString() })}\n\n`));
  req.on('close', () => proc.kill());
});

// ═══════════════════════════════════════════════════════════
//  CONFIG / INFO
// ═══════════════════════════════════════════════════════════
app.get('/api/config', auth, (req, res) => {
  res.json({
    server_ip: C.server.ip,
    hostname: C.server.hostname||'',
    services: C.services,
    ssl: { type:C.ssl.type, domain:C.ssl.domain },
    ports: {
      panel: C.port, ssh:22, ssh_ws:8880,
      openvpn_udp:1194, openvpn_tcp:1195, openvpn_ws:2086, openvpn_ssl:2087,
      xray: C.xray.port, udp:7300
    },
    xray: {
      url: `https://${C.ssl.domain}:${C.xray.port}`,
      local_url: `http://127.0.0.1:${C.xray.port}`,
      username: C.xray.username,
      password: C.xray.password,
      port: C.xray.port
    },
    api_key: C.api_key,
    version: C.version||'1.0.0'
  });
});

// ─── Firewall Rules ────────────────────────────────────────
app.get('/api/firewall', auth, (req, res) => {
  exec('ufw status numbered 2>/dev/null', (e,o) => res.json({ rules:(o||'').split('\n') }));
});

// ─── System Actions ────────────────────────────────────────
app.post('/api/system/reboot', auth, (req, res) => {
  res.json({ success:true, message:'Rebooting in 5 seconds...' });
  setTimeout(() => exec('reboot'), 5000);
});

app.post('/api/system/update-panel', auth, async (req, res) => {
  try {
    await run('cd /opt/vpn-panel && npm update --production');
    res.json({ success:true });
    setTimeout(() => exec('systemctl restart vpn-panel'), 2000);
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ─── Backup ────────────────────────────────────────────────
app.post('/api/backup', auth, async (req, res) => {
  const date = new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
  const outFile = `/tmp/vpn-panel-backup-${date}.tar.gz`;
  try {
    await run(`tar -czf ${outFile} /opt/vpn-panel/config /opt/vpn-panel/clients /etc/vpn-panel 2>/dev/null; true`);
    res.download(outFile, `vpn-panel-backup-${date}.tar.gz`, () => { try{fs.unlinkSync(outFile);}catch{} });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ─── SSH + OpenVPN Payload Templates ────────────────────────
// ส่งคืน config สำเร็จรูปสำหรับแอพทุกตัว
app.get('/api/payload-templates', auth, (req, res) => {
  const ip   = C.server.ip;
  const host = C.ssl.domain || ip;

  // ── SSH Templates ──
  const sshTemplates = [
    {
      app: 'HTTP Injector',
      type: 'ssh',
      icon: '💉',
      config: {
        server: ip, port: 22,
        ws_port: 8880,
        payload: `GET / HTTP/1.1\r\nHost: ${host}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n`,
        sni: host,
        note: 'ใส่ Payload แบบ WebSocket Upgrade'
      },
      // export เป็น JSON สำหรับ import ใน HTTP Injector
      exportJson: {
        name: `SSH-WS ${ip}`,
        host: ip, port: 22,
        proxy: { type: 'SSH', port: 22 },
        payload: `GET / HTTP/1.1[crlf]Host: ${host}[crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf][crlf]`,
        sslSni: host
      }
    },
    {
      app: 'HTTP Custom',
      type: 'ssh',
      icon: '🔧',
      config: {
        server: ip, port: 22,
        ws_port: 8880,
        payload: `GET ws://${host}/ HTTP/1.1\r\nHost: ${host}\r\nUpgrade: websocket\r\n\r\n`,
        protocol: 'websocket'
      }
    },
    {
      app: 'Nexus V2 / HA Tunnel',
      type: 'ssh',
      icon: '🔀',
      config: {
        server: ip, port: 8880,
        type: 'websocket',
        payload: `GET / HTTP/1.1\r\nHost: ${host}\r\nUpgrade: websocket\r\n\r\n`
      }
    },
    {
      app: 'KPN Tunnel',
      type: 'ssh',
      icon: '🚀',
      config: {
        ssh_host: ip, ssh_port: 22,
        payload: `CONNECT ${host}:8880 HTTP/1.1\r\nHost: ${host}\r\n\r\n`
      }
    },
    {
      app: 'AnonyTun / TunnelGuru',
      type: 'ssh',
      icon: '🕵️',
      config: {
        host: ip, port: 22,
        method: 'GET',
        request: `GET / HTTP/1.1\r\nHost: ${host}\r\nUpgrade: websocket\r\n\r\n`
      }
    }
  ];

  // ── OpenVPN WS Templates ──
  const ovpnTemplates = [
    {
      app: 'HTTP Injector',
      type: 'openvpn_ws',
      icon: '💉',
      config: {
        server: ip, port: 2086,
        protocol: 'websocket',
        payload: `GET / HTTP/1.1\r\nHost: ${host}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n`,
        note: 'ใช้ไฟล์ user-ws.ovpn + ตั้ง WS port 2086'
      }
    },
    {
      app: 'HTTP Custom',
      type: 'openvpn_ws',
      icon: '🔧',
      config: {
        server: ip, port: 2086,
        type: 'websocket',
        payload: `GET ws://${host}/ HTTP/1.1\r\nHost: ${host}\r\nUpgrade: websocket\r\n\r\n`
      }
    },
    {
      app: 'OpenVPN SSL (stunnel)',
      type: 'openvpn_ssl',
      icon: '🔐',
      config: {
        server: ip, port: 2087,
        protocol: 'ssl',
        note: 'ใช้ไฟล์ user-ssl.ovpn — เชื่อมต่อผ่าน stunnel'
      }
    }
  ];

  // ── SlowDNS Templates ──
  const slowdnsTemplates = [
    {
      app: 'HTTP Injector SlowDNS',
      type: 'slowdns',
      icon: '🐌',
      config: {
        ns_server: `ns1.${host}`,
        private_key: '(ดูได้จาก /etc/slowdns.conf บน VPS)',
        protocol: 'dns',
        note: 'ต้องมีโดเมนและตั้ง NS record'
      }
    }
  ];

  res.json({
    server: { ip, host, panel_port: C.port },
    ports: {
      ssh: 22, ssh_ws: 8880, udp_gw: 7300,
      ovpn_udp: 1194, ovpn_tcp: 1195,
      ovpn_ws: 2086, ovpn_ssl: 2087
    },
    ssh: sshTemplates,
    openvpn: ovpnTemplates,
    slowdns: slowdnsTemplates
  });
});

// ─── SlowDNS Config ──────────────────────────────────────────
app.get('/api/slowdns-config', auth, (req, res) => {
  const confFile = '/etc/slowdns.conf';
  if (!fs.existsSync(confFile)) return res.json({ enabled:false, msg:'SlowDNS ไม่ได้ติดตั้ง' });
  const conf = fs.readFileSync(confFile,'utf8');
  const key  = conf.match(/SLOWDNS_KEY=(\S+)/)?.[1] || '';
  const ns   = conf.match(/SLOWDNS_NS=(\S+)/)?.[1]  || '';
  res.json({ enabled:true, key, ns, host:C.server.ip,
    instructions: [
      'ตั้ง NS record: ns1.yourdomain.com → ' + C.server.ip,
      'ตั้ง A record:  ns1.yourdomain.com → ' + C.server.ip,
      'ใน HTTP Injector → SlowDNS → ใส่ NS server และ Private Key'
    ]
  });
});

// ─── SSH Config (legacy compat) ──────────────────────────────
app.get('/api/ssh-config', auth, (req, res) => {
  const ip   = C.server.ip;
  const host = C.ssl.domain || ip;
  res.json({
    host: ip, port: 22, ws_port: 8880, udp_port: 7300,
    payload_host: host,
    presets: [
      { name:'HTTP Injector',  host:ip, port:22, ws_port:8880, protocol:'ssh+ws' },
      { name:'HTTP Custom',    host:ip, port:22, ws_port:8880, protocol:'ssh+ws' },
      { name:'Nexus V2',       host:ip, port:22, ws_port:8880, protocol:'ssh+ws' },
      { name:'KPN Tunnel',     host:ip, port:22, ws_port:8880, protocol:'ssh+ws' },
      { name:'HA Tunnel Pro',  host:ip, port:22, ws_port:8880, protocol:'ssh+ws' },
      { name:'AnonyTun',       host:ip, port:22, ws_port:8880, protocol:'ssh+ws' },
    ]
  });
});


// ─── Create Xray client on specific inbound ──────────────────
app.post('/api/xray/client', auth, async (req, res) => {
  try {
    const { inbound_id, email, limitIp, totalGB, expiryTime, enable } = req.body;
    if (!inbound_id) return res.status(400).json({ success:false, msg:'ต้องระบุ inbound_id' });
    const cookie = await getXrayCookie();
    const clientUUID = uuidv4();
    const clientData = {
      id: inbound_id,
      settings: JSON.stringify({
        clients: [{
          id: clientUUID,
          email: email || `user_${Date.now()}`,
          limitIp: parseInt(limitIp) || 0,
          totalGB: parseInt(totalGB) || 0,
          expiryTime: expiryTime || 0,
          enable: enable !== false,
          tgId: '', subId: ''
        }]
      })
    };
    const r = await axios.post(
      `http://127.0.0.1:${C.xray.port}/xui/API/inbounds/addClient`,
      clientData,
      { headers:{ Cookie:cookie, 'Content-Type':'application/json' }, timeout:8000 }
    );
    res.json({ ...r.data, uuid: clientUUID });
  } catch(e) { res.status(500).json({ success:false, msg: e.message }); }
});

// ─── Get Xray client URL (share link) ───────────────────────
app.get('/api/xray/client-url/:inbound_id/:email', auth, async (req, res) => {
  try {
    const cookie = await getXrayCookie();
    const r = await axios.get(
      `http://127.0.0.1:${C.xray.port}/xui/API/inbounds/getClientTraffics/${req.params.email}`,
      { headers:{ Cookie:cookie }, timeout:5000 }
    );
    res.json(r.data);
  } catch(e) { res.status(500).json({ success:false, msg: e.message }); }
});

// ─── Reset Xray client traffic ───────────────────────────────
app.post('/api/xray/client/reset-traffic/:email', auth, async (req, res) => {
  try {
    const cookie = await getXrayCookie();
    const r = await axios.post(
      `http://127.0.0.1:${C.xray.port}/xui/API/inbounds/${req.body.inbound_id}/resetClientTraffic/${req.params.email}`,
      {}, { headers:{ Cookie:cookie }, timeout:5000 }
    );
    res.json(r.data);
  } catch(e) { res.status(500).json({ success:false, msg: e.message }); }
});

// ═══════════════════════════════════════════════════════════
//  FRONTEND FALLBACK
// ═══════════════════════════════════════════════════════════
app.get('*', (req, res) => {
  const idx = path.join(__dirname,'public','index.html');
  if (fs.existsSync(idx)) res.sendFile(idx);
  else res.status(404).send('Panel not found');
});

// ═══════════════════════════════════════════════════════════
//  HTTPS SERVER + WebSocket
// ═══════════════════════════════════════════════════════════
const sslOpts = {
  cert: fs.readFileSync(C.ssl.cert),
  key:  fs.readFileSync(C.ssl.key),
  minVersion: 'TLSv1.2'
};

const server = https.createServer(sslOpts, app);

// ─── WebSocket real-time stats ──────────────────────────────
const wss = new WebSocketServer({ server, path:'/ws' });
const wsClients = new Set();

wss.on('connection', (ws, req) => {
  const params = new URL(req.url, 'https://localhost').searchParams;
  const token  = params.get('token');
  try { jwt.verify(token, C.admin.jwt_secret); }
  catch { ws.close(1008,'Unauthorized'); return; }

  wsClients.add(ws);
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('close', () => wsClients.delete(ws));

  // Send initial data immediately
  pushStats(ws);
});

async function pushStats(target) {
  try {
    const [cpu, mem, nets] = await Promise.all([ si.currentLoad(), si.mem(), si.networkStats() ]);
    const payload = JSON.stringify({
      type:'stats',
      ts: Date.now(),
      cpu: parseFloat(cpu.currentLoad.toFixed(1)),
      cpuCores: cpu.cpus?.length||1,
      memory: {
        used:mem.used, total:mem.total, free:mem.free,
        percent: parseFloat(((mem.used/mem.total)*100).toFixed(1))
      },
      network: { rx: nets[0]?.rx_sec||0, tx: nets[0]?.tx_sec||0 }
    });
    if (target) {
      if (target.readyState===1) target.send(payload);
    } else {
      wsClients.forEach(ws => { if (ws.readyState===1) ws.send(payload); });
    }
  } catch {}
}

// Broadcast every 2s
setInterval(() => pushStats(null), 2000);

// Heartbeat
setInterval(() => {
  wsClients.forEach(ws => {
    if (!ws.isAlive) { wsClients.delete(ws); ws.terminate(); return; }
    ws.isAlive = false; ws.ping();
  });
}, 30000);

// ─── HTTP → HTTPS redirect ──────────────────────────────────
http.createServer((req, res) => {
  const host = (req.headers.host||'').replace(/:\d+$/,'');
  res.writeHead(301, { Location:`https://${host}:${C.port}${req.url}` });
  res.end();
}).listen(8080, () => console.log('[HTTP] Redirect :8080 → :'+C.port));

// ─── Start ──────────────────────────────────────────────────
server.listen(C.port, '0.0.0.0', () => {
  console.log(`[VPN Panel] HTTPS ://0.0.0.0:${C.port}`);
  console.log(`[VPN Panel] 3x-ui @ http://127.0.0.1:${C.xray.port}`);
  console.log(`[VPN Panel] SSL: ${C.ssl.type} (${C.ssl.domain})`);
});

// ─── Graceful shutdown ──────────────────────────────────────
process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
process.on('uncaughtException', e => console.error('[ERROR]', e.message));
process.on('unhandledRejection', e => console.error('[WARN]', e));
