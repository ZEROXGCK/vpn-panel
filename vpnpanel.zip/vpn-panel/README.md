# 🛡️ VPN Panel — คู่มือติดตั้งฉบับละเอียด

ระบบควบคุม VPS/VPN แบบครบวงจร | SSH · OpenVPN · Xray · SlowDNS · UDP

---

## 📦 บริการที่รองรับ

| บริการ | Port | หมายเหตุ |
|--------|------|-----------|
| SSH Tunnel | 22 | Direct |
| SSH WebSocket | 8880 | HTTP Injector, HTTP Custom |
| OpenVPN UDP | 1194 | เร็วสุด |
| OpenVPN TCP | 1195 | เสถียร |
| OpenVPN WebSocket | 2086 | HTTP Injector, HTTP Custom |
| OpenVPN SSL/stunnel | 2087 | Bypass firewall |
| Xray (3x-ui) | สุ่มอัตโนมัติ | VLESS/VMess/Trojan |
| UDP Gateway | 7300 | badvpn-udpgw |
| SlowDNS | 53/udp | ต้องมีโดเมน |
| VPN Panel | 89 (HTTPS) | Web control panel |

---

## 🖥️ ความต้องการของระบบ

- **OS:** Ubuntu 20.04 / 22.04 / 24.04 (แนะนำ) หรือ Debian 10/11/12
- **RAM:** ขั้นต่ำ 512MB (แนะนำ 1GB+)
- **Disk:** ขั้นต่ำ 5GB ว่าง
- **สิทธิ์:** root เท่านั้น
- **Port:** ต้องเปิด 89, 22, 8880, 1194, 1195, 2086, 2087

---

## 🚀 วิธีที่ 1 — อัพโหลดจากเครื่องตัวเองผ่าน SCP

### ขั้นตอนที่ 1: ดาวน์โหลดไฟล์
ดาวน์โหลด `vpn-panel.zip` จาก Panel หรือจาก GitHub

### ขั้นตอนที่ 2: อัพโหลดขึ้น VPS
เปิด Terminal บนเครื่องของคุณ แล้วรัน:

```bash
# อัพโหลด zip ไปที่ /tmp บน VPS
scp vpn-panel.zip root@IP_VPS:/tmp/

# ตัวอย่าง
scp vpn-panel.zip root@103.x.x.x:/tmp/
```

> ถ้า VPS ใช้ key file แทน password:
> ```bash
> scp -i ~/.ssh/id_rsa vpn-panel.zip root@IP_VPS:/tmp/
> ```

### ขั้นตอนที่ 3: SSH เข้า VPS
```bash
ssh root@IP_VPS
```

### ขั้นตอนที่ 4: แตก zip และรัน
```bash
cd /tmp
unzip vpn-panel.zip
cd vpn-panel
chmod +x install.sh menu.sh
bash install.sh
```

### ขั้นตอนที่ 5: ตอบคำถามระหว่างติดตั้ง

สคริปจะถามทีละข้อ:

```
เลือกบริการที่ต้องการติดตั้ง
  1) SSH Tunnel
  2) OpenVPN
  3) Xray (3x-ui)
  4) SlowDNS
  5) UDP Custom
  6) ติดตั้งทั้งหมด  ← พิมพ์ 6 แล้ว Enter

เลือก SSL:
  1) Self-signed (ใช้ IP)  ← ถ้าไม่มีโดเมน พิมพ์ 1
  2) Let's Encrypt          ← ถ้ามีโดเมน พิมพ์ 2

ชื่อ Admin: admin          ← กด Enter ใช้ default
รหัสผ่าน: (ปล่อยว่าง)     ← กด Enter ให้ระบบสุ่มให้
```

รอประมาณ **5–15 นาที** จนเห็น:
```
╔══════════════════════════════════════════╗
║  ✅  ติดตั้งเสร็จสมบูรณ์!              ║
╚══════════════════════════════════════════╝
```

---

## 🐙 วิธีที่ 2 — ติดตั้งผ่าน GitHub (แนะนำ)

### ขั้นตอนที่ 1: Fork Repository
1. ไปที่ GitHub.com → Sign in
2. ไปที่ repo นี้แล้วกด **Fork** (มุมบนขวา)
3. ตั้งชื่อ repo ของคุณเอง เช่น `my-vpn-panel`

### ขั้นตอนที่ 2: Push ไฟล์ขึ้น GitHub

บนเครื่องของคุณ:
```bash
# แตก zip ที่ดาวน์โหลดมา
unzip vpn-panel.zip
cd vpn-panel

# เริ่ม git repo
git init
git add .
git commit -m "Initial VPN Panel"

# เชื่อม remote (เปลี่ยน USERNAME และ REPO_NAME)
git remote add origin https://github.com/USERNAME/REPO_NAME.git
git branch -M main
git push -u origin main
```

### ขั้นตอนที่ 3: ติดตั้งบน VPS จาก GitHub

SSH เข้า VPS แล้วรัน **1 คำสั่ง**:

```bash
bash <(curl -sL https://raw.githubusercontent.com/USERNAME/REPO_NAME/main/install.sh)
```

> เปลี่ยน `USERNAME` และ `REPO_NAME` ให้ตรงกับ GitHub ของคุณ

**หรือ** clone มาก่อน:
```bash
git clone https://github.com/USERNAME/REPO_NAME.git /tmp/vpn-panel
cd /tmp/vpn-panel
bash install.sh
```

### ขั้นตอนที่ 4: อัพเดตในอนาคต

ถ้าแก้ไขไฟล์บนเครื่องแล้ว push ขึ้น GitHub:
```bash
git add .
git commit -m "update panel"
git push
```

แล้วบน VPS รัน:
```bash
cd /tmp/vpn-panel
git pull
bash install.sh   # หรือ npm restart ถ้าแค่แก้ panel
```

---

## 🔑 หลังติดตั้ง — เปิด Panel

เปิด Browser แล้วไปที่:
```
https://IP_VPS:89
```

> ถ้าขึ้น "Not Secure" / "Privacy Error" → กด **Advanced** → **Proceed** ได้เลย (SSL self-signed ปกติ)

**ข้อมูล Login** ดูได้จาก:
```bash
cat /etc/vpn-panel/install-info.txt
```

---

## 💻 คำสั่งที่ใช้บ่อย

```bash
# เปิดเมนูภาษาไทย
menu

# ดูสถานะ Panel
systemctl status vpn-panel

# Restart Panel
systemctl restart vpn-panel

# ดู Log แบบ real-time
journalctl -u vpn-panel -f

# ดูข้อมูลทั้งหมด
cat /etc/vpn-panel/install-info.txt
```

---

## ❓ แก้ปัญหาที่พบบ่อย

**Panel เปิดไม่ได้ / หน้าเว็บขึ้น Error**
```bash
journalctl -u vpn-panel -n 50
# ถ้า Error: Cannot find module → รัน:
cd /opt/vpn-panel && npm install --production
systemctl restart vpn-panel
```

**3x-ui ต่อไม่ได้จาก Panel**
```bash
systemctl status x-ui
# ดู port จริงของ 3x-ui:
cat /etc/vpn-panel/install-info.txt | grep "3x-ui"
```

**OpenVPN WebSocket ต่อไม่ได้**
```bash
systemctl status ovpn-ws
# ถ้า fail → restart:
systemctl restart ovpn-ws stunnel4
```

**Port ถูกบล็อก**
```bash
ufw status
ufw allow 89/tcp
ufw allow 2086/tcp
ufw allow 2087/tcp
```

---

## 📁 โครงสร้างไฟล์หลัง install

```
/opt/vpn-panel/          ← Panel application
├── server.js            ← Node.js backend
├── public/index.html    ← Web UI
├── config/panel.json    ← Config หลัก
├── config/users.json    ← ข้อมูลผู้ใช้
├── clients/             ← ไฟล์ .ovpn ทั้งหมด
└── ssl/                 ← SSL certificates

/etc/vpn-panel/
├── install-info.txt     ← ข้อมูล login ทั้งหมด
└── ssl/                 ← SSL certs ต้นฉบับ

/usr/local/bin/
├── vpn-menu             ← เมนูภาษาไทย
└── ovpn-ws-proxy.py     ← OpenVPN WS proxy
```
