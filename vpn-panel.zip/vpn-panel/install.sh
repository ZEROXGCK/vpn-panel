#!/bin/bash
# ============================================================
#  VPN PANEL INSTALLER - Thai VPS Control Panel
#  รองรับ: SSH Tunnel, OpenVPN, Xray(3x-ui), SlowDNS, UDP
#  เวอร์ชัน: 1.0.0
#
#  ใช้งาน:
#    bash install.sh              ← แบบถามทีละขั้น
#    bash install.sh --auto       ← ติดตั้งทั้งหมด อัตโนมัติ 100%
#    bash install.sh --auto --pass MyPass123
# ============================================================
set -uo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; MAGENTA='\033[0;35m'
WHITE='\033[1;37m'; NC='\033[0m'; BOLD='\033[1m'

PANEL_PORT=89
PANEL_DIR="/opt/vpn-panel"
LOG_FILE="/var/log/vpn-panel-install.log"
XRAY_PORT=$(shuf -i 10000-59999 -n 1)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RESET_TOKEN=""  # จะถูกกำหนดใน install_panel()

# ── CLI Arguments ──────────────────────────────────
AUTO_MODE=false
CUSTOM_PASS=""
for arg in "$@"; do
  case $arg in
    --auto|-y) AUTO_MODE=true ;;
    --pass=*) CUSTOM_PASS="${arg#*=}" ;;
    --pass) shift; CUSTOM_PASS="${1:-}" ;;
  esac
done

# ── SAFE READ — ทำงานได้กับทุก terminal ──────────────
safe_read() {
  local var_name=$1
  local prompt=$2
  local default=${3:-""}
  local result=""

  # ลองอ่านจาก /dev/tty ก่อน (ทำงานได้กับ web terminal)
  if [[ -c /dev/tty ]]; then
    echo -e -n "$prompt" > /dev/tty
    read -r result < /dev/tty || result="$default"
  else
    echo -e -n "$prompt"
    read -r result || result="$default"
  fi

  [[ -z "$result" ]] && result="$default"
  eval "$var_name='$result'"
}

safe_read_secret() {
  local var_name=$1
  local prompt=$2
  local result=""

  if [[ -c /dev/tty ]]; then
    echo -e -n "$prompt" > /dev/tty
    read -rs result < /dev/tty || true
    echo "" > /dev/tty
  else
    echo -e -n "$prompt"
    read -rs result || true
    echo ""
  fi

  eval "$var_name='$result'"
}

# ── PRINT HELPERS ─────────────────────────────────
log_info()  { echo -e "${GREEN}[✓]${NC} $*" | tee -a "$LOG_FILE"; }
log_warn()  { echo -e "${YELLOW}[⚠]${NC} $*" | tee -a "$LOG_FILE"; }
log_error() { echo -e "${RED}[✗]${NC} $*" | tee -a "$LOG_FILE"; }
log_step()  { echo -e "\n${CYAN}[➤]${NC} ${BOLD}$*${NC}" | tee -a "$LOG_FILE"; }
log_data()  { echo -e "    ${MAGENTA}◆${NC} $*" | tee -a "$LOG_FILE"; }
log_raw()   { echo "$*" >> "$LOG_FILE"; }

step_banner() {
  local n=$1; shift
  echo -e "${BLUE}┌──────────────────────────────────────────────────┐${NC}"
  echo -e "${BLUE}│${NC}  ${BOLD}ขั้นตอน ${n}:${NC} $*"
  echo -e "${BLUE}└──────────────────────────────────────────────────┘${NC}"
}

print_banner() {
  clear
  echo -e "${CYAN}"
  cat << 'BANNER'
 ██╗   ██╗██████╗ ███╗   ██╗    ██████╗  █████╗ ███╗   ██╗███████╗██╗
 ██║   ██║██╔══██╗████╗  ██║    ██╔══██╗██╔══██╗████╗  ██║██╔════╝██║
 ██║   ██║██████╔╝██╔██╗ ██║    ██████╔╝███████║██╔██╗ ██║█████╗  ██║
 ╚██╗ ██╔╝██╔═══╝ ██║╚██╗██║    ██╔═══╝ ██╔══██║██║╚██╗██║██╔══╝  ██║
  ╚████╔╝ ██║     ██║ ╚████║    ██║     ██║  ██║██║ ╚████║███████╗███████╗
   ╚═══╝  ╚═╝     ╚═╝  ╚═══╝    ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝
BANNER
  echo -e "${NC}"
  echo -e "${WHITE}         ระบบควบคุม VPS/VPN แบบครบวงจร | Thai VPN Control Panel v1.0${NC}"
  echo -e "${YELLOW}         ══════════════════════════════════════════════════════════${NC}\n"
}

# ── CHECKS ─────────────────────────────────────────
check_root() {
  [[ $EUID -ne 0 ]] && { echo -e "${RED}ต้องรันด้วย root: sudo bash install.sh${NC}"; exit 1; }
}

check_os() {
  log_step "ตรวจสอบระบบปฏิบัติการ"
  [[ -f /etc/os-release ]] && source /etc/os-release || { log_error "ไม่รู้จัก OS"; exit 1; }
  OS=$ID; OS_VER=${VERSION_ID:-""}
  log_info "OS: ${PRETTY_NAME}"
  case $OS in
    ubuntu|debian) PKG="apt-get" ;;
    centos|rhel|almalinux|rocky) PKG="yum" ;;
    fedora) PKG="dnf" ;;
    *) PKG="apt-get"; log_warn "OS ไม่รู้จัก ลองใช้ apt-get" ;;
  esac
}

get_ip() {
  SERVER_IP=$(curl -s4 --max-time 5 ifconfig.me 2>/dev/null \
    || curl -s4 --max-time 5 api.ipify.org 2>/dev/null \
    || hostname -I | awk '{print $1}')
  log_info "Server IP: ${SERVER_IP}"
}

# ── USER SELECTIONS ────────────────────────────────
select_services() {
  if $AUTO_MODE; then
    INST_SSH=true; INST_OVP=true; INST_XRAY=true; INST_SDNS=false; INST_UDP=true
    log_info "Auto mode: ติดตั้ง SSH + OpenVPN + Xray + UDP"
    return
  fi

  echo ""
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${WHITE}  เลือกบริการที่ต้องการติดตั้ง${NC}"
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
  echo -e "  ${CYAN}1)${NC} SSH Tunnel + WebSocket         ${GREEN}[แนะนำ]${NC}"
  echo -e "  ${CYAN}2)${NC} OpenVPN (UDP+TCP+WS+SSL)"
  echo -e "  ${CYAN}3)${NC} Xray ผ่าน 3x-ui               ${GREEN}[VLESS/VMess/Trojan]${NC}"
  echo -e "  ${CYAN}4)${NC} SlowDNS (iodine)"
  echo -e "  ${CYAN}5)${NC} UDP Custom (badvpn-udpgw)"
  echo -e "  ${CYAN}6)${NC} ${WHITE}ติดตั้งทั้งหมด${NC}                 ${MAGENTA}[Full]${NC}\n"

  local SEL
  safe_read SEL "  เลือก (เช่น 1,2,3 หรือ 6): " "6"

  INST_SSH=false; INST_OVP=false; INST_XRAY=false
  INST_SDNS=false; INST_UDP=false

  if [[ "$SEL" == *"6"* || "$SEL" == "6" || -z "$SEL" ]]; then
    INST_SSH=true; INST_OVP=true; INST_XRAY=true; INST_SDNS=false; INST_UDP=true
  else
    [[ "$SEL" == *"1"* ]] && INST_SSH=true
    [[ "$SEL" == *"2"* ]] && INST_OVP=true
    [[ "$SEL" == *"3"* ]] && INST_XRAY=true
    [[ "$SEL" == *"4"* ]] && INST_SDNS=true
    [[ "$SEL" == *"5"* ]] && INST_UDP=true
  fi
  echo ""
  log_info "บริการที่เลือก:"
  $INST_SSH  && log_data "SSH Tunnel + WebSocket"
  $INST_OVP  && log_data "OpenVPN (UDP+TCP+WS+SSL)"
  $INST_XRAY && log_data "Xray / 3x-ui"
  $INST_SDNS && log_data "SlowDNS"
  $INST_UDP  && log_data "UDP Custom"
}

get_ssl_config() {
  if $AUTO_MODE; then
    USE_DOMAIN=false; SSL_DOMAIN="$SERVER_IP"; SSL_TYPE="self-signed"
    log_info "Auto mode: Self-signed SSL สำหรับ IP: $SERVER_IP"
    return
  fi

  echo ""
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${WHITE}  ตั้งค่า SSL Certificate${NC}"
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
  echo -e "  ${CYAN}1)${NC} Self-signed SSL (ใช้ IP Address)  ${GREEN}[ง่าย ไม่ต้องมีโดเมน]${NC}"
  echo -e "  ${CYAN}2)${NC} Let's Encrypt (ต้องมีโดเมน)       ${GREEN}[ฟรี อัพเดตอัตโนมัติ]${NC}\n"

  local SSL_CHOICE
  safe_read SSL_CHOICE "  เลือก [1/2]: " "1"

  if [[ "$SSL_CHOICE" == "2" ]]; then
    local DOMAIN
    safe_read DOMAIN "  กรอกโดเมน (เช่น panel.example.com): " ""
    USE_DOMAIN=true; SSL_DOMAIN="$DOMAIN"
  else
    USE_DOMAIN=false; SSL_DOMAIN="$SERVER_IP"
    log_info "จะใช้ Self-signed SSL สำหรับ IP: $SERVER_IP"
  fi
}

set_credentials() {
  if $AUTO_MODE; then
    ADMIN_USER="admin"
    if [[ -n "$CUSTOM_PASS" ]]; then
      ADMIN_PASS="$CUSTOM_PASS"
    else
      ADMIN_PASS=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)
    fi
    JWT_SECRET=$(openssl rand -hex 32)
    API_KEY=$(openssl rand -hex 24)
    XRAY_USER="xrayadmin"
    XRAY_PASS=$(openssl rand -base64 14 | tr -dc 'a-zA-Z0-9' | head -c 14)
    log_info "Auto mode: Admin=${ADMIN_USER}"
    return
  fi

  echo ""
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${WHITE}  ตั้งค่าข้อมูล Admin${NC}"
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"

  safe_read ADMIN_USER "  ชื่อ Admin (Enter = admin): " "admin"
  safe_read_secret ADMIN_PASS "  รหัสผ่าน Admin (Enter = สุ่ม): "
  [[ -z "$ADMIN_PASS" ]] && ADMIN_PASS=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)

  JWT_SECRET=$(openssl rand -hex 32)
  API_KEY=$(openssl rand -hex 24)
  XRAY_USER="xrayadmin"
  XRAY_PASS=$(openssl rand -base64 14 | tr -dc 'a-zA-Z0-9' | head -c 14)

  echo ""
  log_info "Admin: ${ADMIN_USER} / รหัส: ${ADMIN_PASS}"
  log_info "3x-ui Port: ${XRAY_PORT} (สุ่มอัตโนมัติ)"
}

# ── INSTALL STEPS ──────────────────────────────────

# แสดง spinner แบบ real-time
spin_run() {
  local msg="$1"; shift
  local cmd="$*"
  local spinners=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
  local i=0

  # รัน command ใน background
  eval "$cmd" >> "$LOG_FILE" 2>&1 &
  local pid=$!

  # แสดง spinner ขณะรัน
  while kill -0 $pid 2>/dev/null; do
    echo -ne "  ${CYAN}${spinners[$i]}${NC} ${msg}...\r"
    i=$(( (i+1) % 10 ))
    sleep 0.1
  done

  # เช็คผลลัพธ์
  wait $pid
  local exit_code=$?
  if [[ $exit_code -eq 0 ]]; then
    echo -e "  ${GREEN}✓${NC} ${msg}"
  else
    echo -e "  ${YELLOW}⚠${NC} ${msg} (ข้าม/ล้มเหลว)"
  fi
  return $exit_code
}

# แสดงรายละเอียดขั้นตอนพร้อม progress
detail_log() {
  echo -e "  ${BLUE}│${NC}  ${1}"
}

do_update() {
  step_banner "1" "อัพเดตระบบ"
  detail_log "กำลังดึงรายการ package ใหม่..."
  spin_run "apt-get update" $PKG update -y
  detail_log "กำลัง upgrade package ที่ค้างอยู่..."
  spin_run "apt-get upgrade" $PKG upgrade -y
  log_info "อัพเดตระบบเสร็จแล้ว"
}

install_deps() {
  step_banner "2" "ติดตั้ง Dependencies"
  detail_log "ติดตั้ง packages ที่จำเป็น..."
  echo ""

  local PKGS=(
    "curl:ดาวน์โหลดไฟล์"
    "wget:ดาวน์โหลดไฟล์"
    "git:จัดการ source code"
    "unzip:แตก zip"
    "tar:แตก archive"
    "openssl:เข้ารหัส SSL"
    "net-tools:เครื่องมือ network"
    "htop:monitor system"
    "iptables-persistent:บันทึก firewall rules"
    "python3:Python runtime"
    "python3-pip:Python package manager"
    "bc:คำนวณ"
    "jq:parse JSON"
    "ufw:Firewall"
    "fail2ban:ป้องกัน brute force"
    "sqlite3:database สำหรับ 3x-ui"
    "speedtest-cli:ทดสอบความเร็ว"
    "ca-certificates:SSL certificates"
    "gnupg:GPG keys"
    "lsb-release:ข้อมูล OS"
    "stunnel4:OpenVPN SSL tunnel"
  )

  local total=${#PKGS[@]}
  local current=0

  for entry in "${PKGS[@]}"; do
    local pkg="${entry%%:*}"
    local desc="${entry##*:}"
    current=$((current + 1))
    local pct=$(( current * 100 / total ))
    # Progress bar
    local filled=$(( current * 20 / total ))
    local bar=""
    for ((j=0; j<filled; j++)); do bar+="█"; done
    for ((j=filled; j<20; j++)); do bar+="░"; done

    echo -ne "  ${CYAN}[${bar}]${NC} ${pct}%  ${WHITE}${pkg}${NC} — ${desc}        \r"
    $PKG install -y "$pkg" >> "$LOG_FILE" 2>&1 \
      && echo -e "  ${GREEN}✓${NC} [${pct}%] ${WHITE}${pkg}${NC} — ${desc}          " \
      || echo -e "  ${YELLOW}⚠${NC} [${pct}%] ${WHITE}${pkg}${NC} (ข้าม)"
  done

  echo ""
  log_info "Dependencies ติดตั้งเสร็จทั้งหมด"
}

install_nodejs() {
  step_banner "3" "ติดตั้ง Node.js 20"
  if command -v node &>/dev/null; then
    log_info "Node.js $(node --version) มีอยู่แล้ว — ข้าม"
    return
  fi
  detail_log "ดาวน์โหลด NodeSource setup script..."
  spin_run "ดาวน์โหลด NodeSource" curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >> "$LOG_FILE" 2>&1
  detail_log "ติดตั้ง nodejs..."
  spin_run "ติดตั้ง Node.js 20" $PKG install -y nodejs
  log_info "Node.js $(node --version) | npm $(npm --version)"
}

setup_ssl() {
  step_banner "4" "ตั้งค่า SSL Certificate"
  mkdir -p /etc/vpn-panel/ssl

  if $USE_DOMAIN; then
    detail_log "ติดตั้ง Certbot สำหรับ Let's Encrypt..."
    spin_run "ติดตั้ง certbot" $PKG install -y certbot
    systemctl stop nginx 2>/dev/null || true
    detail_log "ขอ Certificate จาก Let's Encrypt สำหรับ ${SSL_DOMAIN}..."
    spin_run "Let's Encrypt: ${SSL_DOMAIN}" certbot certonly --standalone --non-interactive --agree-tos --email "admin@${SSL_DOMAIN}" -d "${SSL_DOMAIN}"
    if [[ -f "/etc/letsencrypt/live/${SSL_DOMAIN}/fullchain.pem" ]]; then
      ln -sf /etc/letsencrypt/live/${SSL_DOMAIN}/fullchain.pem /etc/vpn-panel/ssl/cert.pem
      ln -sf /etc/letsencrypt/live/${SSL_DOMAIN}/privkey.pem  /etc/vpn-panel/ssl/key.pem
      SSL_TYPE="letsencrypt"
      log_info "Let's Encrypt SSL สำเร็จ ✓"
      (crontab -l 2>/dev/null; echo "0 3 * * * certbot renew --quiet") | crontab -
    else
      log_warn "Let's Encrypt ล้มเหลว → ใช้ Self-signed แทน"
      make_self_signed
    fi
  else
    make_self_signed
  fi
}

make_self_signed() {
  detail_log "สร้าง Self-signed SSL Certificate อายุ 10 ปี..."
  spin_run "สร้าง SSL Certificate" openssl req -x509 -nodes -days 3650 -newkey rsa:2048 \
    -keyout /etc/vpn-panel/ssl/key.pem \
    -out    /etc/vpn-panel/ssl/cert.pem \
    -subj "/C=TH/ST=Bangkok/L=Bangkok/O=VPN Panel/CN=${SSL_DOMAIN}" \
    -addext "subjectAltName=IP:${SERVER_IP},DNS:${SERVER_IP}"
  SSL_TYPE="self-signed"
  log_info "Self-signed SSL สร้างแล้ว"
}

inst_ssh() {
  $INST_SSH || return 0
  step_banner "5a" "ตั้งค่า SSH + WebSocket Proxy"

  detail_log "ตั้งค่า SSH config (AllowTcpForwarding, GatewayPorts)..."
  grep -q "AllowTcpForwarding yes" /etc/ssh/sshd_config || cat >> /etc/ssh/sshd_config << 'SSHCFG'
# VPN Panel
AllowTcpForwarding yes
GatewayPorts yes
X11Forwarding no
MaxAuthTries 3
ClientAliveInterval 60
ClientAliveCountMax 3
SSHCFG
  log_info "SSH config ✓"

  # SSH Banner
  cat > /etc/issue.net << 'BANNER'
┌─────────────────────────────────────────────────┐
│         VPN Panel - SSH Tunnel Server           │
│         Unauthorized access is forbidden        │
└─────────────────────────────────────────────────┘
BANNER
  grep -q "Banner /etc/issue.net" /etc/ssh/sshd_config || echo "Banner /etc/issue.net" >> /etc/ssh/sshd_config

  detail_log "ติดตั้ง Python websockets library..."
  spin_run "pip install websockets" pip3 install websockets --break-system-packages 2>/dev/null || \
    spin_run "pip install websockets (fallback)" pip3 install websockets 2>/dev/null || true

  detail_log "สร้าง WebSocket SSH proxy script..."
  cat > /usr/local/bin/ws-ssh-proxy.py << 'WSPY'
#!/usr/bin/env python3
"""WebSocket → SSH proxy on port 8880"""
import asyncio, websockets, logging
logging.basicConfig(level=logging.WARNING)

async def proxy(ws):
    try:
        reader, writer = await asyncio.open_connection('127.0.0.1', 22)
        async def ws2ssh():
            try:
                async for msg in ws:
                    writer.write(msg if isinstance(msg, bytes) else msg.encode())
                    await writer.drain()
            except Exception: writer.close()
        async def ssh2ws():
            try:
                while True:
                    data = await reader.read(4096)
                    if not data: break
                    await ws.send(data)
            except Exception: pass
        await asyncio.gather(ws2ssh(), ssh2ws())
    except Exception: pass

async def main():
    async with websockets.serve(proxy, '0.0.0.0', 8880, ping_interval=30):
        await asyncio.Future()

asyncio.run(main())
WSPY
  chmod +x /usr/local/bin/ws-ssh-proxy.py

  detail_log "สร้าง systemd service สำหรับ ws-ssh..."
  cat > /etc/systemd/system/ws-ssh.service << 'WSSVC'
[Unit]
Description=WebSocket SSH Proxy
After=network.target ssh.service

[Service]
Type=simple
ExecStart=/usr/bin/python3 /usr/local/bin/ws-ssh-proxy.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
WSSVC

  systemctl daemon-reload
  spin_run "enable + start ws-ssh" systemctl enable ws-ssh
  spin_run "restart SSH daemon" systemctl restart ssh
  spin_run "start ws-ssh proxy" systemctl start ws-ssh
  log_info "SSH Port: 22 | WebSocket Port: 8880"
}

inst_openvpn() {
  $INST_OVP || return 0
  step_banner "5b" "ติดตั้ง OpenVPN + WebSocket + SSL/Stunnel + User/Pass"

  $PKG install -y openvpn easy-rsa stunnel4 python3-websockets >> "$LOG_FILE" 2>&1

  local EASY="/etc/openvpn/easy-rsa"
  mkdir -p "$EASY"
  cp -r /usr/share/easy-rsa/* "$EASY/" 2>/dev/null || make-cadir "$EASY" 2>/dev/null || true
  cd "$EASY"

  cat > vars << 'VARS'
set_var EASYRSA_ALGO        ec
set_var EASYRSA_CURVE       prime256v1
set_var EASYRSA_DIGEST      sha256
set_var EASYRSA_CA_EXPIRE   3650
set_var EASYRSA_CERT_EXPIRE 3650
VARS

  log_info "สร้าง PKI / CA / Server Certificate..."
  ./easyrsa --batch init-pki               >> "$LOG_FILE" 2>&1
  ./easyrsa --batch build-ca nopass        >> "$LOG_FILE" 2>&1
  ./easyrsa --batch gen-req server nopass  >> "$LOG_FILE" 2>&1
  ./easyrsa --batch sign-req server server >> "$LOG_FILE" 2>&1
  ./easyrsa --batch gen-dh                 >> "$LOG_FILE" 2>&1
  openvpn --genkey secret /etc/openvpn/ta.key >> "$LOG_FILE" 2>&1

  cp pki/ca.crt pki/private/server.key pki/issued/server.crt /etc/openvpn/
  cp pki/dh.pem /etc/openvpn/

  local WAN; WAN=$(ip route | awk '/^default/{print $5}' | head -1)
  mkdir -p /var/log/openvpn /etc/openvpn/auth

  # ── สร้าง auth script สำหรับ username/password ──────────────
  cat > /etc/openvpn/auth/checkpsw.sh << 'AUTHSH'
#!/bin/bash
# OpenVPN username/password auth script
# อ่าน user/pass จากไฟล์ที่ OpenVPN ส่งมา
PASSFILE="/etc/openvpn/auth/users.db"
LOG="/var/log/openvpn/auth.log"
USERNAME=$(head -1 "$1")
PASSWORD=$(tail -1 "$1")

if [[ -z "$USERNAME" || -z "$PASSWORD" ]]; then
  echo "$(date) AUTH FAIL: empty credentials" >> "$LOG"
  exit 1
fi

# ตรวจสอบจาก users.db  (format: username:sha256hash)
HASH=$(echo -n "$PASSWORD" | sha256sum | awk '{print $1}')
if grep -qE "^${USERNAME}:${HASH}$" "$PASSFILE" 2>/dev/null; then
  echo "$(date) AUTH OK: $USERNAME" >> "$LOG"
  exit 0
fi

# fallback: เทียบ plaintext (สำหรับ legacy)
if grep -qE "^${USERNAME}:${PASSWORD}$" "$PASSFILE" 2>/dev/null; then
  echo "$(date) AUTH OK (plain): $USERNAME" >> "$LOG"
  exit 0
fi

echo "$(date) AUTH FAIL: $USERNAME" >> "$LOG"
exit 1
AUTHSH
  chmod +x /etc/openvpn/auth/checkpsw.sh
  touch /etc/openvpn/auth/users.db
  chmod 600 /etc/openvpn/auth/users.db

  # ── server.conf (UDP 1194) — cert + optional user/pass ───────
  cat > /etc/openvpn/server.conf << OVCFG
port 1194
proto udp
dev tun
ca ca.crt
cert server.crt
key server.key
dh dh.pem
tls-auth ta.key 0
server 10.8.0.0 255.255.255.0
ifconfig-pool-persist /var/log/openvpn/ipp.txt
push "redirect-gateway def1 bypass-dhcp"
push "dhcp-option DNS 8.8.8.8"
push "dhcp-option DNS 1.1.1.1"
keepalive 10 120
cipher AES-256-GCM
auth SHA256
compress lz4-v2
push "compress lz4-v2"
persist-key
persist-tun
# Username/Password auth (optional, cert ก็พอแล้ว)
auth-user-pass-verify /etc/openvpn/auth/checkpsw.sh via-file
script-security 3
username-as-common-name
verify-client-cert optional
status /var/log/openvpn/status.log
log-append /var/log/openvpn/openvpn.log
verb 3
explicit-exit-notify 1
OVCFG

  # ── server-tcp.conf (TCP 1195) — สำหรับ WS proxy ────────────
  cat > /etc/openvpn/server-tcp.conf << OVTCP
port 1195
proto tcp
dev tun1
ca ca.crt
cert server.crt
key server.key
dh dh.pem
tls-auth ta.key 0
server 10.9.0.0 255.255.255.0
push "redirect-gateway def1 bypass-dhcp"
push "dhcp-option DNS 8.8.8.8"
push "dhcp-option DNS 1.1.1.1"
keepalive 10 120
cipher AES-256-GCM
auth SHA256
compress lz4-v2
push "compress lz4-v2"
persist-key
persist-tun
auth-user-pass-verify /etc/openvpn/auth/checkpsw.sh via-file
script-security 3
username-as-common-name
verify-client-cert optional
status /var/log/openvpn/status-tcp.log
log-append /var/log/openvpn/openvpn-tcp.log
verb 3
OVTCP

  # ── OpenVPN over WebSocket (port 2086) ───────────────────────
  log_info "ติดตั้ง OpenVPN WebSocket proxy (port 2086)..."
  cat > /usr/local/bin/ovpn-ws-proxy.py << 'OWSPY'
#!/usr/bin/env python3
"""
OpenVPN WebSocket Proxy
รับ WebSocket จาก client บน port 2086
แล้ว forward ไป OpenVPN TCP บน port 1195
ใช้กับ HTTP Injector, HTTP Custom, Nexus, HA Tunnel
"""
import asyncio, websockets, logging, signal, sys
logging.basicConfig(level=logging.WARNING)

OVPN_HOST = '127.0.0.1'
OVPN_PORT = 1195
LISTEN_PORT = 2086

async def handle(ws):
    client = ws.remote_address
    try:
        reader, writer = await asyncio.open_connection(OVPN_HOST, OVPN_PORT)
        async def ws_to_ovpn():
            try:
                async for msg in ws:
                    data = msg if isinstance(msg, bytes) else msg.encode()
                    writer.write(data)
                    await writer.drain()
            except Exception: pass
            finally: writer.close()
        async def ovpn_to_ws():
            try:
                while True:
                    data = await reader.read(16384)
                    if not data: break
                    await ws.send(data)
            except Exception: pass
        await asyncio.gather(ws_to_ovpn(), ovpn_to_ws())
    except Exception as e:
        pass

async def main():
    stop = asyncio.Future()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stop.set_result, None)
    async with websockets.serve(
        handle, '0.0.0.0', LISTEN_PORT,
        ping_interval=30, ping_timeout=20,
        max_size=2**20
    ):
        print(f'[ovpn-ws] listening on ws://0.0.0.0:{LISTEN_PORT} → {OVPN_HOST}:{OVPN_PORT}')
        await stop

asyncio.run(main())
OWSPY
  chmod +x /usr/local/bin/ovpn-ws-proxy.py

  cat > /etc/systemd/system/ovpn-ws.service << 'OWSSVC'
[Unit]
Description=OpenVPN WebSocket Proxy (port 2086)
After=network.target openvpn@server-tcp.service

[Service]
Type=simple
ExecStart=/usr/bin/python3 /usr/local/bin/ovpn-ws-proxy.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
OWSSVC

  # ── stunnel — OpenVPN over SSL/TLS (port 2087) ───────────────
  log_info "ตั้งค่า stunnel (OpenVPN over SSL port 2087)..."
  cat > /etc/stunnel/stunnel.conf << STLCFG
; stunnel config — OpenVPN over SSL
pid = /var/run/stunnel4/stunnel4.pid
output = /var/log/stunnel4/stunnel.log
socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1

[ovpn-ssl]
accept  = 2087
connect = 127.0.0.1:1195
cert    = /etc/vpn-panel/ssl/cert.pem
key     = /etc/vpn-panel/ssl/key.pem
STLCFG

  mkdir -p /var/log/stunnel4
  # เปิด stunnel4 auto-start
  sed -i 's/^ENABLED=0/ENABLED=1/' /etc/default/stunnel4 2>/dev/null || true

  # ── IP forwarding + NAT ──────────────────────────────────────
  grep -q 'net.ipv4.ip_forward=1' /etc/sysctl.conf || echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf
  sysctl -p >> "$LOG_FILE" 2>&1

  for subnet in 10.8.0.0/24 10.9.0.0/24; do
    iptables -t nat -A POSTROUTING -s "$subnet" -o "$WAN" -j MASQUERADE 2>/dev/null || true
  done
  mkdir -p /etc/iptables
  iptables-save > /etc/iptables/rules.v4 2>/dev/null || true

  # ── Enable & start services ──────────────────────────────────
  systemctl daemon-reload
  for svc in openvpn@server openvpn@server-tcp ovpn-ws stunnel4; do
    systemctl enable "$svc" >> "$LOG_FILE" 2>&1 || true
    systemctl start  "$svc" >> "$LOG_FILE" 2>&1 || true
  done

  log_info "OpenVPN UDP  : 1194  (cert + user/pass)"
  log_info "OpenVPN TCP  : 1195  (cert + user/pass)"
  log_info "OpenVPN WS   : 2086  (WebSocket → TCP 1195)"
  log_info "OpenVPN SSL  : 2087  (stunnel → TCP 1195)"
}

inst_xray() {
  $INST_XRAY || return 0
  step_banner "5c" "ติดตั้ง 3x-ui (Xray)"

  detail_log "ดาวน์โหลด 3x-ui installer จาก GitHub..."
  echo -e "  ${YELLOW}⏳${NC} กำลังดาวน์โหลดและติดตั้ง 3x-ui... (อาจใช้เวลา 1-3 นาที)"

  if bash <(curl -Ls https://raw.githubusercontent.com/MHSanaei/3x-ui/master/install.sh) << 'XEOF' >> "$LOG_FILE" 2>&1
y
XEOF
  then
    echo -e "  ${GREEN}✓${NC} 3x-ui ติดตั้งสำเร็จ"
    sleep 3
    detail_log "ตั้งค่า port และ credentials สำหรับ 3x-ui..."
    local DB="/usr/local/x-ui/x-ui.db"
    if [[ -f "$DB" ]]; then
      sqlite3 "$DB" "UPDATE settings SET value='${XRAY_PORT}'                WHERE key='webPort';"     2>/dev/null || true
      sqlite3 "$DB" "UPDATE settings SET value='${XRAY_USER}'               WHERE key='webUsername';" 2>/dev/null || true
      sqlite3 "$DB" "UPDATE settings SET value='${XRAY_PASS}'               WHERE key='webPassword';" 2>/dev/null || true
      sqlite3 "$DB" "UPDATE settings SET value='/etc/vpn-panel/ssl/cert.pem' WHERE key='webCertFile';" 2>/dev/null || true
      sqlite3 "$DB" "UPDATE settings SET value='/etc/vpn-panel/ssl/key.pem'  WHERE key='webKeyFile';"  2>/dev/null || true
      log_info "3x-ui database ตั้งค่าแล้ว"
    fi
    spin_run "restart x-ui service" systemctl restart x-ui
    sleep 2
    log_info "3x-ui Port: ${XRAY_PORT} | User: ${XRAY_USER}"
  else
    log_warn "3x-ui ติดตั้งไม่สำเร็จ (ข้าม)"
  fi
}

inst_slowdns() {
  $INST_SDNS || return 0
  step_banner "5d" "ติดตั้ง SlowDNS (iodine)"
  spin_run "ติดตั้ง iodine + dnsmasq" $PKG install -y iodine dnsmasq || log_warn "iodine ไม่พบใน repo (ข้าม)"

  SDNS_KEY=$(openssl rand -hex 16)
  SDNS_PORT=5300

  detail_log "สร้าง config file /etc/slowdns.conf..."
  cat > /etc/slowdns.conf << SDNS
SLOWDNS_KEY=${SDNS_KEY}
SLOWDNS_NS=ns1.${SSL_DOMAIN}
SLOWDNS_PORT=${SDNS_PORT}
SDNS

  detail_log "สร้าง systemd service สำหรับ SlowDNS..."
  cat > /etc/systemd/system/slowdns.service << SLSVC
[Unit]
Description=SlowDNS (iodine DNS tunnel)
After=network.target

[Service]
Type=simple
EnvironmentFile=/etc/slowdns.conf
ExecStart=/usr/sbin/iodined -f -c -P \${SLOWDNS_KEY} 10.53.0.0/24 ns1.${SSL_DOMAIN}
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
SLSVC

  systemctl daemon-reload
  spin_run "enable slowdns" systemctl enable slowdns
  spin_run "start slowdns"  systemctl start slowdns || log_warn "SlowDNS ต้องการโดเมนจึงจะทำงานได้"
  log_info "SlowDNS Key: ${SDNS_KEY} | NS: ns1.${SSL_DOMAIN}"
}

inst_udp() {
  $INST_UDP || return 0
  step_banner "5e" "ติดตั้ง UDP Custom (badvpn-udpgw)"
  spin_run "ติดตั้ง cmake + build-essential" $PKG install -y cmake build-essential || true

  local ARCH; ARCH=$(uname -m)
  detail_log "Architecture: ${ARCH}"

  if [[ "$ARCH" == "x86_64" ]]; then
    detail_log "ดาวน์โหลด badvpn prebuilt binary..."
    spin_run "ดาวน์โหลด badvpn" wget -q -O /tmp/badvpn.tar.gz \
      "https://github.com/ambrop72/badvpn/releases/download/1.999.130/badvpn-1.999.130-linux-x86_64.tar.gz"
    tar -xzf /tmp/badvpn.tar.gz -C /tmp >> "$LOG_FILE" 2>&1 && \
      cp /tmp/badvpn*/udpgw/badvpn-udpgw /usr/local/bin/ 2>/dev/null && \
      chmod +x /usr/local/bin/badvpn-udpgw || true
  fi

  if [[ ! -f /usr/local/bin/badvpn-udpgw ]]; then
    detail_log "Build badvpn จาก source code..."
    cd /tmp
    spin_run "git clone badvpn" git clone --depth=1 https://github.com/ambrop72/badvpn.git
    mkdir -p badvpn/build && cd badvpn/build
    spin_run "cmake configure" cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1
    spin_run "make build" make
    cp udpgw/badvpn-udpgw /usr/local/bin/ >> "$LOG_FILE" 2>&1 || log_warn "Build ล้มเหลว"
  fi

  detail_log "สร้าง systemd service สำหรับ udpgw..."
  cat > /etc/systemd/system/udpgw.service << 'UDPSVC'
[Unit]
Description=UDP Gateway (badvpn)
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 500 --max-connections-for-client 10
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UDPSVC

  systemctl daemon-reload
  spin_run "enable udpgw" systemctl enable udpgw
  spin_run "start udpgw"  systemctl start udpgw || log_warn "udpgw อาจยังไม่พร้อม"
  log_info "UDP Gateway Port: 7300"
}

setup_firewall() {
  step_banner "6" "ตั้งค่า Firewall (UFW)"

  detail_log "รีเซ็ต UFW rules..."
  spin_run "ufw reset" ufw --force reset

  detail_log "ตั้งค่า default policy..."
  ufw default deny incoming  >> "$LOG_FILE" 2>&1
  ufw default allow outgoing >> "$LOG_FILE" 2>&1

  echo ""
  local rules=(
    "22/tcp:SSH"
    "8080/tcp:HTTP redirect"
    "8880/tcp:SSH WebSocket"
    "${PANEL_PORT}/tcp:VPN Panel"
    "${XRAY_PORT}/tcp:3x-ui Xray"
  )
  $INST_OVP  && rules+=("1194/udp:OpenVPN UDP" "1195/tcp:OpenVPN TCP" "2086/tcp:OpenVPN WS" "2087/tcp:OpenVPN SSL")
  $INST_SDNS && rules+=("53/udp:SlowDNS")
  $INST_UDP  && rules+=("7300/udp:UDP Gateway")

  for rule in "${rules[@]}"; do
    local port="${rule%%:*}"
    local desc="${rule##*:}"
    ufw allow "$port" >> "$LOG_FILE" 2>&1
    echo -e "  ${GREEN}✓${NC} เปิด port ${WHITE}${port}${NC} — ${desc}"
  done

  echo ""
  spin_run "เปิดใช้งาน UFW" ufw --force enable
  log_info "Firewall ตั้งค่าแล้ว"

  detail_log "ตั้งค่า Fail2ban สำหรับป้องกัน brute force..."
  cat > /etc/fail2ban/jail.local << 'F2B'
[sshd]
enabled  = true
maxretry = 5
bantime  = 3600
findtime = 600
F2B
  spin_run "restart fail2ban" systemctl restart fail2ban || true
  log_info "Fail2ban ป้องกัน SSH brute force"
}

install_panel() {
  step_banner "7" "ติดตั้ง VPN Panel"

  detail_log "สร้างโฟลเดอร์ ${PANEL_DIR}..."
  mkdir -p "${PANEL_DIR}"/{public,config,clients,logs,ssl}
  log_info "สร้างโฟลเดอร์ ✓"

  detail_log "คัดลอก SSL Certificate..."
  cp /etc/vpn-panel/ssl/cert.pem "${PANEL_DIR}/ssl/"
  cp /etc/vpn-panel/ssl/key.pem  "${PANEL_DIR}/ssl/"
  log_info "SSL certs คัดลอกแล้ว ✓"

  # หา panel source
  detail_log "ค้นหาไฟล์ Panel..."
  local PANEL_SRC=""
  for try_path in \
      "${SCRIPT_DIR}/panel" \
      "$(dirname "$0")/panel" \
      "/tmp/vpn-panel/panel"; do
    if [[ -d "$try_path" && -f "$try_path/server.js" ]]; then
      PANEL_SRC="$try_path"; break
    fi
  done

  if [[ -n "$PANEL_SRC" ]]; then
    spin_run "คัดลอกไฟล์ Panel" cp -r "${PANEL_SRC}/"* "${PANEL_DIR}/"
    log_info "Panel files จาก: ${PANEL_SRC} ✓"
  else
    log_warn "ไม่พบ panel/ — ใช้ fallback..."
    create_panel_files
  fi

  detail_log "สร้าง config file..."
  # ใช้ Node.js สร้าง hash ให้ตรงกับ server.js ทุกครั้ง
  local ADMIN_HASH
  ADMIN_HASH=$(node -e "const c=require('crypto');console.log(c.createHash('sha256').update('${ADMIN_PASS}').digest('hex'));" 2>/dev/null \
    || echo -n "${ADMIN_PASS}" | sha256sum | awk '{print $1}')

  # สร้าง reset token สำหรับกู้คืนรหัสผ่านฉุกเฉิน (global)
  RESET_TOKEN=$(openssl rand -hex 16)
  mkdir -p /etc/vpn-panel
  echo "$RESET_TOKEN" > /etc/vpn-panel/reset_token
  chmod 600 /etc/vpn-panel/reset_token

  cat > "${PANEL_DIR}/config/panel.json" << CFG
{
  "version": "1.0.0",
  "port": ${PANEL_PORT},
  "ssl": {
    "enabled": true,
    "cert": "${PANEL_DIR}/ssl/cert.pem",
    "key": "${PANEL_DIR}/ssl/key.pem",
    "type": "${SSL_TYPE}",
    "domain": "${SSL_DOMAIN}"
  },
  "admin": {
    "username": "${ADMIN_USER}",
    "password_hash": "${ADMIN_HASH}",
    "jwt_secret": "${JWT_SECRET}"
  },
  "api_key": "${API_KEY}",
  "server": {
    "ip": "${SERVER_IP}",
    "hostname": "$(hostname)"
  },
  "services": {
    "ssh": ${INST_SSH},
    "openvpn": ${INST_OVP},
    "xray": ${INST_XRAY},
    "slowdns": ${INST_SDNS},
    "udp": ${INST_UDP}
  },
  "xray": {
    "port": ${XRAY_PORT},
    "username": "${XRAY_USER}",
    "password": "${XRAY_PASS}"
  }
}
CFG
  log_info "Config file สร้างแล้ว ✓"

  [[ -f "${PANEL_DIR}/config/users.json" ]] || echo "[]" > "${PANEL_DIR}/config/users.json"

  detail_log "ติดตั้ง Node.js packages (อาจใช้เวลา 1-2 นาที)..."
  cd "${PANEL_DIR}"
  # แสดง package ที่กำลังโหลด
  echo -e "  ${CYAN}⠋${NC} npm install --production..."
  npm install --production 2>&1 | while IFS= read -r line; do
    if echo "$line" | grep -qE "added [0-9]+ packages"; then
      echo -e "  ${GREEN}✓${NC} $line"
    elif echo "$line" | grep -qE "^npm warn|^npm error" ; then
      echo -e "  ${YELLOW}⚠${NC} $line"
    fi
  done
  log_info "Node.js packages ติดตั้งแล้ว ✓"
}

create_panel_files() {
  # สร้าง package.json ขั้นต่ำ
  cat > "${PANEL_DIR}/package.json" << 'PKGJSON'
{
  "name": "vpn-panel",
  "version": "1.0.0",
  "main": "server.js",
  "dependencies": {
    "express": "^4.18.2",
    "jsonwebtoken": "^9.0.2",
    "axios": "^1.6.7",
    "cors": "^2.8.5",
    "ws": "^8.16.0",
    "node-cron": "^3.0.3",
    "systeminformation": "^5.22.6",
    "uuid": "^9.0.1",
    "express-rate-limit": "^7.2.0",
    "archiver": "^6.0.1"
  }
}
PKGJSON
  log_warn "กรุณา copy panel/server.js และ panel/public/index.html ลงใน ${PANEL_DIR}/ ด้วยตนเอง"
  log_warn "หรือรัน: cp panel/* ${PANEL_DIR}/ && cp panel/public/index.html ${PANEL_DIR}/public/"
}

install_service() {
  step_banner "8" "สร้าง Systemd Service"
  detail_log "สร้าง /etc/systemd/system/vpn-panel.service..."
  cat > /etc/systemd/system/vpn-panel.service << SVC
[Unit]
Description=VPN Control Panel
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=${PANEL_DIR}
ExecStart=/usr/bin/node ${PANEL_DIR}/server.js
Restart=always
RestartSec=5
StandardOutput=append:/var/log/vpn-panel.log
StandardError=append:/var/log/vpn-panel.log
Environment=NODE_ENV=production NODE_OPTIONS=--max-old-space-size=256

[Install]
WantedBy=multi-user.target
SVC

  spin_run "systemctl daemon-reload" systemctl daemon-reload
  spin_run "enable vpn-panel" systemctl enable vpn-panel
  log_info "Systemd service สร้างแล้ว"
}

install_menu_cmd() {
  step_banner "9" "ติดตั้งเมนูภาษาไทย"
  detail_log "คัดลอก menu.sh → /usr/local/bin/vpn-menu..."
  cp "${SCRIPT_DIR}/menu.sh" /usr/local/bin/vpn-menu
  chmod +x /usr/local/bin/vpn-menu
  ln -sf /usr/local/bin/vpn-menu /usr/local/bin/menu 2>/dev/null || true
  grep -q "alias menu=" /root/.bashrc || echo 'alias menu="vpn-menu"' >> /root/.bashrc
  log_info "ติดตั้งเมนูแล้ว — พิมพ์ 'menu' เพื่อเปิด"
}

start_all() {
  step_banner "10" "เริ่มต้นบริการทั้งหมด"
  echo ""

  local svcs=()
  $INST_SSH  && svcs+=("ws-ssh:SSH WebSocket proxy")
  $INST_OVP  && svcs+=("openvpn@server:OpenVPN UDP" "openvpn@server-tcp:OpenVPN TCP" "ovpn-ws:OpenVPN WebSocket" "stunnel4:OpenVPN SSL")
  $INST_UDP  && svcs+=("udpgw:UDP Gateway")
  svcs+=("vpn-panel:VPN Control Panel")

  for entry in "${svcs[@]}"; do
    local svc="${entry%%:*}"
    local desc="${entry##*:}"
    if spin_run "start ${desc}" systemctl start "$svc"; then
      echo -e "  ${GREEN}●${NC} ${desc} — ${GREEN}กำลังทำงาน${NC}"
    else
      echo -e "  ${YELLOW}○${NC} ${desc} — ${YELLOW}อาจยังไม่พร้อม${NC}"
    fi
  done

  echo ""
  sleep 2
  if systemctl is-active --quiet vpn-panel; then
    log_info "VPN Panel เริ่มทำงานแล้ว ✓"
  else
    log_warn "Panel ยังไม่พร้อม ดู log: journalctl -u vpn-panel -n 30"
  fi
}

save_info() {
  mkdir -p /etc/vpn-panel
  cat > /etc/vpn-panel/install-info.txt << INFO
═══════════════════════════════════════════════════════
 VPN PANEL - ข้อมูลการติดตั้ง
 วันที่: $(date '+%Y-%m-%d %H:%M:%S')
═══════════════════════════════════════════════════════
 Panel URL    : https://${SSL_DOMAIN}:${PANEL_PORT}
 Admin User   : ${ADMIN_USER}
 Admin Pass   : ${ADMIN_PASS}
 JWT Secret   : ${JWT_SECRET}
 API Key      : ${API_KEY}
─────────────────────────────────────────────────────
 🆘 Emergency Reset Token: ${RESET_TOKEN}
 Reset URL: POST https://${SSL_DOMAIN}:${PANEL_PORT}/api/emergency-reset
─────────────────────────────────────────────────────
 3x-ui URL    : https://${SSL_DOMAIN}:${XRAY_PORT}
 3x-ui User   : ${XRAY_USER}
 3x-ui Pass   : ${XRAY_PASS}
─────────────────────────────────────────────────────
 Server IP    : ${SERVER_IP}
 SSL Type     : ${SSL_TYPE}
 SSL Domain   : ${SSL_DOMAIN}
─────────────────────────────────────────────────────
 SSH Port     : 22
 WS-SSH Port  : 8880
 OpenVPN UDP  : 1194  (cert + user/pass)
 OpenVPN TCP  : 1195  (cert + user/pass)
 OpenVPN WS   : 2086  (WebSocket → 1195)
 OpenVPN SSL  : 2087  (stunnel SSL → 1195)
 UDP Gateway  : 7300
═══════════════════════════════════════════════════════
INFO
  chmod 600 /etc/vpn-panel/install-info.txt
}

show_summary() {
  echo ""
  echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║${WHITE}                ✅  ติดตั้งเสร็จสมบูรณ์!                       ${GREEN}║${NC}"
  echo -e "${GREEN}╠══════════════════════════════════════════════════════════════╣${NC}"
  echo -e "${GREEN}║${NC}"
  echo -e "${GREEN}║${NC}  ${CYAN}🌐 Panel URL:${NC}"
  echo -e "${GREEN}║${NC}     ${WHITE}https://${SSL_DOMAIN}:${PANEL_PORT}${NC}"
  echo -e "${GREEN}║${NC}"
  echo -e "${GREEN}║${NC}  ${CYAN}🔐 Admin Login:${NC}"
  echo -e "${GREEN}║${NC}     Username : ${WHITE}${ADMIN_USER}${NC}"
  echo -e "${GREEN}║${NC}     Password : ${WHITE}${ADMIN_PASS}${NC}"
  echo -e "${GREEN}║${NC}"
  if $INST_XRAY; then
    echo -e "${GREEN}║${NC}  ${CYAN}⚡ 3x-ui Panel:${NC}"
    echo -e "${GREEN}║${NC}     URL      : ${WHITE}https://${SSL_DOMAIN}:${XRAY_PORT}${NC}"
    echo -e "${GREEN}║${NC}     Username : ${WHITE}${XRAY_USER}${NC}"
    echo -e "${GREEN}║${NC}     Password : ${WHITE}${XRAY_PASS}${NC}"
    echo -e "${GREEN}║${NC}"
  fi
  echo -e "${GREEN}║${NC}  ${CYAN}🔑 API Key:${NC}"
  echo -e "${GREEN}║${NC}     ${WHITE}${API_KEY}${NC}"
  echo -e "${GREEN}║${NC}"
  echo -e "${GREEN}║${NC}  ${CYAN}🆘 Emergency Reset Token:${NC}"
  echo -e "${GREEN}║${NC}     ${WHITE}${RESET_TOKEN}${NC}"
  echo -e "${GREEN}║${NC}     POST https://${SSL_DOMAIN}:${PANEL_PORT}/api/emergency-reset"
  echo -e "${GREEN}║${NC}"
  echo -e "${GREEN}║${NC}  ${CYAN}🚪 Ports:${NC}"
  echo -e "${GREEN}║${NC}     Panel    : ${PANEL_PORT}  |  3x-ui : ${XRAY_PORT}"
  $INST_SSH && echo -e "${GREEN}║${NC}     SSH      : 22    |  WS-SSH: 8880"
  $INST_OVP && echo -e "${GREEN}║${NC}     OpenVPN  : UDP:1194 | TCP:1195 | WS:2086 | SSL:2087"
  $INST_UDP && echo -e "${GREEN}║${NC}     UDP-GW   : 7300"
  echo -e "${GREEN}║${NC}"
  echo -e "${GREEN}║${NC}  ${YELLOW}💡 คำสั่ง:${NC}"
  echo -e "${GREEN}║${NC}     เมนู    : ${WHITE}menu${NC}  หรือ  ${WHITE}vpn-menu${NC}"
  echo -e "${GREEN}║${NC}     สถานะ   : ${WHITE}systemctl status vpn-panel${NC}"
  echo -e "${GREEN}║${NC}     Log     : ${WHITE}journalctl -u vpn-panel -f${NC}"
  echo -e "${GREEN}║${NC}"
  echo -e "${GREEN}║${NC}  ${MAGENTA}💾 ข้อมูลบันทึกไว้ที่: /etc/vpn-panel/install-info.txt${NC}"
  echo -e "${GREEN}║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

# ── MAIN ──────────────────────────────────────────
mkdir -p /etc/vpn-panel
touch "$LOG_FILE"
print_banner
check_root
check_os
get_ip
select_services
get_ssl_config
set_credentials

echo ""
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${WHITE}  เริ่มการติดตั้ง... กรุณารอ (5-20 นาที)${NC}"
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

do_update
install_deps
install_nodejs
setup_ssl
inst_ssh
inst_openvpn
inst_xray
inst_slowdns
inst_udp
setup_firewall
install_panel
install_service
install_menu_cmd
start_all
save_info
show_summary
