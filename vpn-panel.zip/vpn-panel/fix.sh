#!/bin/bash
# ============================================================
#  VPN PANEL FIX SCRIPT
#  แก้ปัญหา: Login ไม่ได้ + 3x-ui เข้าไม่ได้
# ============================================================
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; WHITE='\033[1;37m'; NC='\033[0m'

[[ $EUID -ne 0 ]] && { echo -e "${RED}ต้องรันด้วย root${NC}"; exit 1; }

CFG="/opt/vpn-panel/config/panel.json"
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  VPN Panel Fix Script                   ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── 1. ตรวจสอบ config ───────────────────────────────────
echo -e "${CYAN}[1/5]${NC} ตรวจสอบ Config..."
if [[ ! -f "$CFG" ]]; then
  echo -e "${RED}ไม่พบ config! ต้องรัน install.sh ก่อน${NC}"; exit 1
fi
echo -e "${GREEN}✓${NC} Config: $CFG"

# ── 2. แก้ password hash ────────────────────────────────
echo -e "${CYAN}[2/5]${NC} แก้ไข Password Hash..."
CURRENT_PASS=$(python3 -c "import json; d=json.load(open('$CFG')); print(d['admin'].get('password_plain','') or d['admin'].get('password_hash',''))" 2>/dev/null || \
  node -e "const d=require('$CFG');console.log(d.admin.password_plain||d.admin.password_hash||'')" 2>/dev/null)

# อ่าน admin pass จาก install-info.txt
INFO_PASS=$(grep "Admin Pass" /etc/vpn-panel/install-info.txt 2>/dev/null | awk -F': ' '{print $2}' | xargs)

if [[ -n "$INFO_PASS" ]]; then
  echo -e "  ${CYAN}รหัสผ่านจาก install-info:${NC} $INFO_PASS"
  NEW_HASH=$(node -e "const c=require('crypto');console.log(c.createHash('sha256').update('$INFO_PASS').digest('hex'));" 2>/dev/null)
  if [[ -n "$NEW_HASH" ]]; then
    node << NODESCRIPT
const fs = require('fs');
const crypto = require('crypto');
const cfg = JSON.parse(fs.readFileSync('$CFG','utf8'));
const pass = '$INFO_PASS';
cfg.admin.password_hash = crypto.createHash('sha256').update(pass).digest('hex');
delete cfg.admin.password_plain;
fs.writeFileSync('$CFG', JSON.stringify(cfg,null,2));
console.log('Hash updated: ' + cfg.admin.password_hash.substring(0,16) + '...');
NODESCRIPT
    echo -e "${GREEN}✓${NC} Password hash อัพเดตแล้ว"
  fi
else
  echo -e "${YELLOW}⚠${NC} ไม่พบรหัสผ่านจาก install-info.txt"
  echo -e "  ${WHITE}กรุณารีเซ็ตรหัสผ่านเองผ่าน emergency-reset${NC}"
fi

# ── 3. สร้าง reset token ใหม่ ────────────────────────────
echo -e "${CYAN}[3/5]${NC} สร้าง Emergency Reset Token..."
NEW_TOKEN=$(openssl rand -hex 16)
echo "$NEW_TOKEN" > /etc/vpn-panel/reset_token
chmod 600 /etc/vpn-panel/reset_token
echo -e "${GREEN}✓${NC} Reset Token: ${WHITE}$NEW_TOKEN${NC}"

# ── 4. แก้ 3x-ui ────────────────────────────────────────
echo -e "${CYAN}[4/5]${NC} ตรวจสอบและแก้ไข 3x-ui..."
XRAY_PORT=$(node -e "const d=require('$CFG');console.log(d.xray.port)" 2>/dev/null || \
  python3 -c "import json;d=json.load(open('$CFG'));print(d['xray']['port'])" 2>/dev/null)
XRAY_USER=$(node -e "const d=require('$CFG');console.log(d.xray.username)" 2>/dev/null || echo "xrayadmin")
XRAY_PASS=$(node -e "const d=require('$CFG');console.log(d.xray.password)" 2>/dev/null)

echo -e "  3x-ui Port: ${WHITE}$XRAY_PORT${NC}"
echo -e "  3x-ui User: ${WHITE}$XRAY_USER${NC}"

# ตั้งค่า 3x-ui ใหม่ถ้า database มี
DB="/usr/local/x-ui/x-ui.db"
if [[ -f "$DB" ]]; then
  sqlite3 "$DB" "UPDATE settings SET value='$XRAY_PORT' WHERE key='webPort';"     2>/dev/null
  sqlite3 "$DB" "UPDATE settings SET value='$XRAY_USER' WHERE key='webUsername';" 2>/dev/null
  sqlite3 "$DB" "UPDATE settings SET value='$XRAY_PASS' WHERE key='webPassword';" 2>/dev/null
  sqlite3 "$DB" "UPDATE settings SET value='/etc/vpn-panel/ssl/cert.pem' WHERE key='webCertFile';" 2>/dev/null
  sqlite3 "$DB" "UPDATE settings SET value='/etc/vpn-panel/ssl/key.pem'  WHERE key='webKeyFile';"  2>/dev/null
  echo -e "${GREEN}✓${NC} 3x-ui database อัพเดตแล้ว"
  systemctl restart x-ui 2>/dev/null && echo -e "${GREEN}✓${NC} 3x-ui restart แล้ว" || true
else
  echo -e "${YELLOW}⚠${NC} ไม่พบ 3x-ui database — อาจยังไม่ได้ติดตั้ง"
fi

# เปิด port ของ 3x-ui
ufw allow "$XRAY_PORT/tcp" >> /dev/null 2>&1 && \
  echo -e "${GREEN}✓${NC} เปิด UFW port $XRAY_PORT"

# ── 5. Restart Panel ────────────────────────────────────
echo -e "${CYAN}[5/5]${NC} Restart VPN Panel..."
systemctl restart vpn-panel
sleep 3
if systemctl is-active --quiet vpn-panel; then
  echo -e "${GREEN}✓${NC} VPN Panel กำลังทำงาน"
else
  echo -e "${RED}✗${NC} Panel ไม่ start — ดู log:"
  journalctl -u vpn-panel -n 15 --no-pager
fi

# ── สรุป ────────────────────────────────────────────────
SERVER_IP=$(curl -s4 --max-time 5 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
PANEL_PORT=$(node -e "const d=require('$CFG');console.log(d.port)" 2>/dev/null || echo "89")

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  ✅ แก้ไขเสร็จแล้ว!${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║${NC}  Panel: ${WHITE}https://${SERVER_IP}:${PANEL_PORT}${NC}"
echo -e "${GREEN}║${NC}  User : ${WHITE}$(node -e "const d=require('$CFG');console.log(d.admin.username)" 2>/dev/null)${NC}"
echo -e "${GREEN}║${NC}  Pass : ${WHITE}${INFO_PASS:-ดูจาก /etc/vpn-panel/install-info.txt}${NC}"
echo -e "${GREEN}║${NC}  3x-ui: ${WHITE}https://${SERVER_IP}:${XRAY_PORT}${NC}"
echo -e "${GREEN}║${NC}"
echo -e "${GREEN}║${NC}  🆘 Emergency Reset Token: ${WHITE}${NEW_TOKEN}${NC}"
echo -e "${GREEN}║${NC}  ใช้ที่: Panel → ลืมรหัสผ่าน"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""
