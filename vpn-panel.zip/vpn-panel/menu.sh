#!/bin/bash
# ============================================================
#  VPN PANEL MENU - เมนูภาษาไทย
#  ควบคุม VPS/VPN ผ่าน Terminal
# ============================================================
[[ $EUID -ne 0 ]] && { echo "ต้องรันด้วย root"; exit 1; }

RED='\033[0;31m';GREEN='\033[0;32m';YELLOW='\033[1;33m'
BLUE='\033[0;34m';CYAN='\033[0;36m';MAGENTA='\033[0;35m'
WHITE='\033[1;37m';NC='\033[0m';BOLD='\033[1m'

CFG="/opt/vpn-panel/config/panel.json"
USERS="/opt/vpn-panel/config/users.json"
CLIENTS="/opt/vpn-panel/clients"

[[ ! -f "$CFG" ]] && { echo -e "${RED}ไม่พบ config กรุณาติดตั้ง Panel ก่อน${NC}"; exit 1; }

load_cfg() {
  SERVER_IP=$(jq -r '.server.ip'           "$CFG")
  PANEL_PORT=$(jq -r '.port'               "$CFG")
  XRAY_PORT=$(jq -r '.xray.port'           "$CFG")
  SSL_DOMAIN=$(jq -r '.ssl.domain'         "$CFG")
  XRAY_USER=$(jq -r '.xray.username'       "$CFG")
  XRAY_PASS=$(jq -r '.xray.password'       "$CFG")
  ADMIN_USER=$(jq -r '.admin.username'     "$CFG")
  API_KEY=$(jq -r '.api_key'               "$CFG")
  SVC_SSH=$(jq -r '.services.ssh'          "$CFG")
  SVC_OVP=$(jq -r '.services.openvpn'     "$CFG")
  SVC_XRAY=$(jq -r '.services.xray'        "$CFG")
  SVC_UDP=$(jq -r '.services.udp'          "$CFG")
}

hdr() {
  clear
  local cpu; cpu=$(top -bn1 2>/dev/null | grep "Cpu(s)" | awk '{print $2}' | cut -d. -f1)
  local mem_used; mem_used=$(free -m | awk '/^Mem:/{print $3}')
  local mem_total; mem_total=$(free -m | awk '/^Mem:/{print $2}')
  local uptime; uptime=$(uptime -p 2>/dev/null | sed 's/up //' || echo "--")
  echo -e "${CYAN}╔══════════════════════════════════════════════════════════════╗${NC}"
  echo -e "${CYAN}║${WHITE}         🛡️  VPN PANEL  |  ระบบควบคุม VPS/VPN                ${CYAN}║${NC}"
  echo -e "${CYAN}╠══════════════════════════════════════════════════════════════╣${NC}"
  echo -e "${CYAN}║${NC}  IP: ${GREEN}${SERVER_IP}${NC}  Panel: ${GREEN}https://${SSL_DOMAIN}:${PANEL_PORT}${NC}"
  echo -e "${CYAN}║${NC}  CPU: ${cpu:-?}%  RAM: ${mem_used}/${mem_total}MB  Uptime: ${uptime}"
  echo -e "${CYAN}╚══════════════════════════════════════════════════════════════╝${NC}"
}

svc_badge() {
  systemctl is-active --quiet "$1" 2>/dev/null \
    && echo -e "${GREEN}[ON]${NC}" || echo -e "${RED}[OFF]${NC}"
}

press_enter() {
  echo -e -n "\n  ${YELLOW}กด Enter เพื่อกลับ...${NC}"
  if [[ -c /dev/tty ]]; then read -r < /dev/tty; else read -r; fi
}
confirm() {
  echo -e -n "  ${RED}ยืนยัน? (yes/no): ${NC}"
  local c=""
  if [[ -c /dev/tty ]]; then read -r c < /dev/tty; else read -r c; fi
  [[ "$c" == "yes" ]]
}
mread() {
  # safe read สำหรับ menu — ทำงานได้กับ web terminal
  local var=$1 prompt=$2 default=${3:-""}
  echo -e -n "$prompt"
  local val=""
  if [[ -c /dev/tty ]]; then read -r val < /dev/tty; else read -r val; fi
  [[ -z "$val" ]] && val="$default"
  eval "$var='$val'"
}

# ═══════════════════════════════════════════════════
#  MAIN MENU
# ═══════════════════════════════════════════════════
main_menu() {
  while true; do
    hdr
    echo ""
    echo -e "  ${YELLOW}════════════ เมนูหลัก ════════════${NC}"
    echo -e "  ${GREEN}1)${NC} 👤 จัดการบัญชี SSH"
    [[ "$SVC_OVP" == "true" ]]  && echo -e "  ${GREEN}2)${NC} 🔒 จัดการ OpenVPN"
    [[ "$SVC_XRAY" == "true" ]] && echo -e "  ${GREEN}3)${NC} ⚡ จัดการ Xray / 3x-ui"
    echo -e "  ${GREEN}4)${NC} 📊 สถานะระบบ"
    echo -e "  ${GREEN}5)${NC} 🚀 ทดสอบความเร็วอินเตอร์เน็ต"
    echo -e "  ${GREEN}6)${NC} ⚙️  จัดการบริการ (Service)"
    echo -e "  ${GREEN}7)${NC} 📋 ดู Log"
    echo -e "  ${GREEN}8)${NC} ℹ️  ข้อมูลการเชื่อมต่อ"
    echo -e "  ${GREEN}9)${NC} 💾 สำรองข้อมูล"
    echo -e "  ${GREEN}0)${NC} 🚪 ออก"
    echo ""
    mread ch "  ${WHITE}เลือก: ${NC}"
    case $ch in
      1) ssh_menu ;;
      2) [[ "$SVC_OVP"  == "true" ]] && ovpn_menu  || echo -e "${RED}OpenVPN ไม่ได้ติดตั้ง${NC}" ;;
      3) [[ "$SVC_XRAY" == "true" ]] && xray_menu  || echo -e "${RED}Xray ไม่ได้ติดตั้ง${NC}" ;;
      4) sys_status ;;
      5) speed_menu ;;
      6) svc_menu ;;
      7) log_menu ;;
      8) conn_info ;;
      9) backup_menu ;;
      0) echo -e "${GREEN}ออกจากเมนู${NC}"; exit 0 ;;
      *) ;;
    esac
  done
}

# ═══════════════════════════════════════════════════
#  SSH MENU
# ═══════════════════════════════════════════════════
ssh_menu() {
  while true; do
    hdr
    local cnt; cnt=$(grep -c '"type":"ssh"' "$USERS" 2>/dev/null || echo 0)
    local online; online=$(who | grep -v root | wc -l)
    echo ""
    echo -e "  ${YELLOW}════════════ จัดการ SSH ════════════${NC}"
    echo -e "  ${CYAN}บัญชีทั้งหมด: ${WHITE}${cnt}${NC}  |  Online: ${GREEN}${online}${NC}"
    echo ""
    echo -e "  ${GREEN}1)${NC} ➕ สร้างบัญชีใหม่"
    echo -e "  ${GREEN}2)${NC} 📋 ดูบัญชีทั้งหมด"
    echo -e "  ${GREEN}3)${NC} 👥 ดูผู้ใช้ Online"
    echo -e "  ${GREEN}4)${NC} 🔄 ต่ออายุบัญชี"
    echo -e "  ${GREEN}5)${NC} ❌ ลบบัญชี"
    echo -e "  ${GREEN}6)${NC} 🔒 แบน/ปลดแบน บัญชี"
    echo -e "  ${GREEN}0)${NC} ◀️  กลับ"
    echo ""
    mread ch "  ${WHITE}เลือก: ${NC}"
    case $ch in
      1) ssh_create ;;
      2) ssh_list ;;
      3) ssh_online ;;
      4) ssh_renew ;;
      5) ssh_delete ;;
      6) ssh_ban ;;
      0) break ;;
    esac
  done
}

ssh_create() {
  hdr
  echo -e "\n  ${YELLOW}═══ สร้างบัญชี SSH ใหม่ ═══${NC}\n"
  mread uname "  ${WHITE}ชื่อผู้ใช้: ${NC}"
  [[ -z "$uname" ]] && { echo -e "${RED}ต้องกรอกชื่อผู้ใช้${NC}"; sleep 1; return; }
  if [[ -c /dev/tty ]]; then echo -e -n "  ${WHITE}รหัสผ่าน (Enter=สุ่ม): ${NC}" >/dev/tty; read -rs upass </dev/tty; echo "" >/dev/tty; else echo -e -n "  ${WHITE}รหัสผ่าน: ${NC}"; read -rs upass; echo ""; fi
  [[ -z "$upass" ]] && upass=$(openssl rand -base64 10 | tr -dc 'a-zA-Z0-9' | head -c 12)
  mread days "  ${WHITE}จำนวนวัน [30]: ${NC}" "30"
  mread lim "  ${WHITE}Limit Connection [2]: ${NC}" "2"

  local exp; exp=$(date -d "+${days} days" +%Y-%m-%d)
  echo -e "\n  ${CYAN}กำลังสร้าง...${NC}"

  useradd -M -s /bin/false -e "$exp" "$uname" 2>/dev/null || true
  echo "${uname}:${upass}" | chpasswd

  # Save to users.json
  local uid; uid=$(cat /proc/sys/kernel/random/uuid 2>/dev/null || uuidgen 2>/dev/null || date +%s)
  local iso_exp; iso_exp=$(date -d "$exp" -u +%Y-%m-%dT%H:%M:%SZ)
  local now_iso; now_iso=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  python3 -c "
import json, sys
data = json.load(open('$USERS'))
data.append({'id':'$uid','type':'ssh','username':'$uname','password':'$upass',
  'created':'$now_iso','expires':'$iso_exp','days':$days,'limit_conn':$lim,
  'quota':'unlimited','active':True})
json.dump(data, open('$USERS','w'), indent=2)
" 2>/dev/null || true

  echo ""
  echo -e "${GREEN}  ╔══════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}  ║  ✅ สร้างบัญชีสำเร็จ!${NC}"
  echo -e "${GREEN}  ╠══════════════════════════════════════════╣${NC}"
  echo -e "${GREEN}  ║${NC}  Host     : ${WHITE}${SERVER_IP}${NC}"
  echo -e "${GREEN}  ║${NC}  Port     : ${WHITE}22${NC}"
  echo -e "${GREEN}  ║${NC}  Username : ${WHITE}${uname}${NC}"
  echo -e "${GREEN}  ║${NC}  Password : ${WHITE}${upass}${NC}"
  echo -e "${GREEN}  ║${NC}  Expires  : ${WHITE}${exp}${NC}"
  echo -e "${GREEN}  ║${NC}  WS URL   : ${WHITE}ws://${SERVER_IP}:8880${NC}"
  echo -e "${GREEN}  ║${NC}  UDP Port : ${WHITE}7300${NC}"
  echo -e "${GREEN}  ╚══════════════════════════════════════════╝${NC}"
  press_enter
}

ssh_list() {
  hdr
  echo -e "\n  ${YELLOW}═══ รายชื่อบัญชี SSH ═══${NC}\n"
  printf "  %-18s %-14s %-12s %-8s\n" "USERNAME" "EXPIRES" "STATUS" "LIMIT"
  echo -e "  ${BLUE}────────────────────────────────────────────────${NC}"
  while IFS=: read -r u _ uid _ _ _ sh; do
    [[ "$sh" == "/bin/false" && $uid -ge 1000 ]] || continue
    local exp; exp=$(chage -l "$u" 2>/dev/null | awk -F': ' '/Account expires/{print $2}')
    local stat; stat=$(id "$u" 2>/dev/null | grep -q "nologin" && echo "Banned" || echo "Active")
    printf "  ${WHITE}%-18s${NC} %-14s ${GREEN}%-12s${NC} %-8s\n" "$u" "${exp:-never}" "$stat" "2"
  done < /etc/passwd
  echo ""
  press_enter
}

ssh_online() {
  hdr
  echo -e "\n  ${YELLOW}═══ ผู้ใช้ SSH Online ═══${NC}\n"
  local lines; lines=$(who 2>/dev/null | grep -v "root\|LOGIN" || echo "")
  if [[ -z "$lines" ]]; then
    echo -e "  ${YELLOW}ไม่มีผู้ใช้ Online${NC}"
  else
    printf "  %-15s %-15s %-20s\n" "USER" "IP/SOURCE" "SINCE"
    echo -e "  ${BLUE}──────────────────────────────────────────────${NC}"
    echo "$lines" | while read -r line; do
      printf "  %-15s %-15s %-20s\n" \
        "$(echo "$line" | awk '{print $1}')" \
        "$(echo "$line" | awk '{print $3}')" \
        "$(echo "$line" | awk '{print $4" "$5}')"
    done
  fi
  press_enter
}

ssh_renew() {
  hdr
  echo -e "\n  ${YELLOW}═══ ต่ออายุบัญชี SSH ═══${NC}\n"
  mread uname "  ${WHITE}ชื่อบัญชี: ${NC}"
  [[ -z "$uname" ]] && return
  mread days "  ${WHITE}จำนวนวันที่เพิ่ม [30]: ${NC}" "30"
  local new_exp; new_exp=$(date -d "+${days} days" +%Y-%m-%d)
  chage -E "$new_exp" "$uname" 2>/dev/null \
    && echo -e "\n  ${GREEN}✅ ต่ออายุ ${uname} ถึง ${new_exp}${NC}" \
    || echo -e "\n  ${RED}ไม่พบบัญชี ${uname}${NC}"
  press_enter
}

ssh_delete() {
  hdr
  echo -e "\n  ${YELLOW}═══ ลบบัญชี SSH ═══${NC}\n"
  mread uname "  ${WHITE}ชื่อบัญชีที่จะลบ: ${NC}"
  [[ -z "$uname" || "$uname" == "root" ]] && return
  echo -e "  ${RED}กำลังจะลบ: ${uname}${NC}"
  confirm || { echo "ยกเลิก"; sleep 1; return; }
  pkill -u "$uname" 2>/dev/null || true
  userdel "$uname" 2>/dev/null && echo -e "  ${GREEN}✅ ลบ ${uname} แล้ว${NC}" || echo -e "  ${RED}ไม่พบ${NC}"
  # Remove from users.json
  python3 -c "
import json
data = json.load(open('$USERS'))
data = [u for u in data if u.get('username') != '$uname']
json.dump(data, open('$USERS','w'), indent=2)
" 2>/dev/null || true
  press_enter
}

ssh_ban() {
  hdr
  echo -e "\n  ${YELLOW}═══ แบน/ปลดแบน บัญชี ═══${NC}\n"
  mread uname "  ${WHITE}ชื่อบัญชี: ${NC}"
  [[ -z "$uname" ]] && return
  echo -e "  ${CYAN}1) แบน  2) ปลดแบน${NC}"
  mread ch "  เลือก: "
  if [[ "$ch" == "1" ]]; then
    passwd -l "$uname" 2>/dev/null && pkill -u "$uname" 2>/dev/null || true
    echo -e "  ${GREEN}✅ แบน ${uname} แล้ว${NC}"
  else
    passwd -u "$uname" 2>/dev/null
    echo -e "  ${GREEN}✅ ปลดแบน ${uname} แล้ว${NC}"
  fi
  press_enter
}

# ═══════════════════════════════════════════════════
#  OPENVPN MENU
# ═══════════════════════════════════════════════════
ovpn_menu() {
  while true; do
    hdr
    echo -e "\n  ${YELLOW}════════════ OpenVPN ════════════${NC}\n"
    echo -e "  ${GREEN}1)${NC} ➕ สร้าง Client ใหม่ (.ovpn)"
    echo -e "  ${GREEN}2)${NC} 📋 รายชื่อ Client"
    echo -e "  ${GREEN}3)${NC} ❌ ลบ/Revoke Client"
    echo -e "  ${GREEN}4)${NC} 📊 ดู Status"
    echo -e "  ${GREEN}0)${NC} ◀️  กลับ"
    echo ""
    mread ch "  ${WHITE}เลือก: ${NC}"
    case $ch in
      1) ovpn_create ;;
      2) ovpn_list ;;
      3) ovpn_revoke ;;
      4) ovpn_status ;;
      0) break ;;
    esac
  done
}

ovpn_create() {
  hdr
  echo -e "\n  ${YELLOW}═══ สร้าง OpenVPN Client ═══${NC}\n"
  mread cname "  ${WHITE}ชื่อ Client: ${NC}"
  [[ -z "$cname" ]] && return
  mread days "  ${WHITE}จำนวนวัน [30]: ${NC}" "30"

  echo -e "\n  ${CYAN}เลือกโหมดที่ต้องการสร้าง:${NC}"
  echo -e "  ${GREEN}1)${NC} ทั้งหมด (UDP + TCP + WS + SSL) ${MAGENTA}[แนะนำ]${NC}"
  echo -e "  ${GREEN}2)${NC} UDP port 1194 เท่านั้น"
  echo -e "  ${GREEN}3)${NC} WebSocket port 2086 เท่านั้น"
  echo -e "  ${GREEN}4)${NC} SSL/stunnel port 2087 เท่านั้น"
  mread msel "  เลือก [1]: " "1"

  mread upuser "\n  ${WHITE}Username สำหรับ auth (Enter=ไม่ใช้): ${NC}"
  local uppass=""
  if [[ -n "$upuser" ]]; then
    if [[ -c /dev/tty ]]; then echo -e -n "  ${WHITE}Password: ${NC}" >/dev/tty; read -rs uppass </dev/tty; echo "" >/dev/tty; else echo -e -n "  ${WHITE}Password: ${NC}"; read -rs uppass; echo ""; fi
  fi

  echo -e "\n  ${CYAN}กำลังสร้าง Certificate... (15-30 วินาที)${NC}"
  local EASY="/etc/openvpn/easy-rsa"
  cd "$EASY" || { echo -e "${RED}ไม่พบ easy-rsa${NC}"; press_enter; return; }
  ./easyrsa --batch gen-req "$cname" nopass >> /dev/null 2>&1
  ./easyrsa --batch sign-req client "$cname" >> /dev/null 2>&1

  local CA; CA=$(cat pki/ca.crt)
  local CERT_RAW; CERT_RAW=$(cat "pki/issued/${cname}.crt" 2>/dev/null)
  local CERT; CERT=$(echo "$CERT_RAW" | awk '/-----BEGIN CERTIFICATE-----/,/-----END CERTIFICATE-----/')
  local KEY; KEY=$(cat "pki/private/${cname}.key" 2>/dev/null)
  local TA;  TA=$(cat /etc/openvpn/ta.key 2>/dev/null)

  # บันทึก user/pass ถ้ามี
  if [[ -n "$upuser" && -n "$uppass" ]]; then
    local HASH; HASH=$(echo -n "$uppass" | sha256sum | awk '{print $1}')
    sed -i "/^${upuser}:/d" /etc/openvpn/auth/users.db 2>/dev/null || true
    echo "${upuser}:${HASH}" >> /etc/openvpn/auth/users.db
  fi

  local CRED_BLOCK=""
  [[ -n "$upuser" ]] && CRED_BLOCK="auth-user-pass"

  local BASE_OPTS="resolv-retry infinite
nobind
persist-key
persist-tun
remote-cert-tls server
cipher AES-256-GCM
auth SHA256
compress lz4-v2
verb 3"

  local CERT_BLOCK="<ca>
${CA}
</ca>
<cert>
${CERT}
</cert>
<key>
${KEY}
</key>
<tls-auth>
${TA}
</tls-auth>
key-direction 1"

  local HEADER="# VPN Panel - ${cname} | สร้างเมื่อ: $(date '+%Y-%m-%d %H:%M:%S')"

  mkdir -p "$CLIENTS"

  build_ovpn() {
    local fname=$1 proto=$2 remote_host=$3 remote_port=$4
    cat > "${CLIENTS}/${fname}" << FOVPN
${HEADER}
client
dev tun
proto ${proto}
remote ${remote_host} ${remote_port}
${BASE_OPTS}
${CRED_BLOCK}
${CERT_BLOCK}
FOVPN
  }

  local created_files=()
  case $msel in
    1)
      build_ovpn "${cname}-udp.ovpn"  udp "${SERVER_IP}" 1194; created_files+=("${cname}-udp.ovpn")
      build_ovpn "${cname}-tcp.ovpn"  tcp "${SERVER_IP}" 1195; created_files+=("${cname}-tcp.ovpn")
      build_ovpn "${cname}-ws.ovpn"   tcp "${SERVER_IP}" 2086; created_files+=("${cname}-ws.ovpn")
      build_ovpn "${cname}-ssl.ovpn"  tcp "${SERVER_IP}" 2087; created_files+=("${cname}-ssl.ovpn")
      # default .ovpn = udp
      cp "${CLIENTS}/${cname}-udp.ovpn" "${CLIENTS}/${cname}.ovpn"
      ;;
    2) build_ovpn "${cname}-udp.ovpn" udp "${SERVER_IP}" 1194; created_files+=("${cname}-udp.ovpn") ;;
    3) build_ovpn "${cname}-ws.ovpn"  tcp "${SERVER_IP}" 2086; created_files+=("${cname}-ws.ovpn") ;;
    4) build_ovpn "${cname}-ssl.ovpn" tcp "${SERVER_IP}" 2087; created_files+=("${cname}-ssl.ovpn") ;;
  esac

  echo ""
  echo -e "${GREEN}  ╔══════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}  ║  ✅ สร้าง OpenVPN Client สำเร็จ!${NC}"
  echo -e "${GREEN}  ╠══════════════════════════════════════════════════╣${NC}"
  for f in "${created_files[@]}"; do
    echo -e "${GREEN}  ║${NC}  📄 ${CLIENTS}/${f}"
  done
  [[ -n "$upuser" ]] && echo -e "${GREEN}  ║${NC}  🔑 User/Pass: ${WHITE}${upuser} / ***${NC}"
  echo -e "${GREEN}  ║${NC}  🌐 ดาวน์โหลดจาก: https://${SSL_DOMAIN}:${PANEL_PORT}"
  echo -e "${GREEN}  ║${NC}"
  echo -e "${GREEN}  ║${NC}  Ports: UDP ${WHITE}1194${NC} | TCP ${WHITE}1195${NC} | WS ${WHITE}2086${NC} | SSL ${WHITE}2087${NC}"
  echo -e "${GREEN}  ╚══════════════════════════════════════════════════╝${NC}"
  press_enter
}

ovpn_list() {
  hdr
  echo -e "\n  ${YELLOW}═══ รายชื่อ OpenVPN Clients ═══${NC}\n"
  ls "${CLIENTS}"/*.ovpn 2>/dev/null | while read -r f; do
    local name; name=$(basename "$f" .ovpn)
    local size; size=$(du -h "$f" | cut -f1)
    echo -e "  ${GREEN}▸${NC} ${name}  (${size})"
  done || echo -e "  ${YELLOW}ยังไม่มี Client${NC}"
  press_enter
}

ovpn_revoke() {
  hdr
  mread cname "  ${WHITE}ชื่อ Client ที่จะลบ: ${NC}"
  [[ -z "$cname" ]] && return
  confirm || return
  cd /etc/openvpn/easy-rsa
  ./easyrsa --batch revoke "$cname" >> /dev/null 2>&1
  ./easyrsa --batch gen-crl >> /dev/null 2>&1
  rm -f "${CLIENTS}/${cname}.ovpn"
  echo -e "  ${GREEN}✅ Revoke ${cname} แล้ว${NC}"
  press_enter
}

ovpn_status() {
  hdr
  echo -e "\n  ${YELLOW}═══ OpenVPN Status ═══${NC}\n"
  systemctl status openvpn@server --no-pager 2>/dev/null | head -20
  echo ""
  echo -e "  ${CYAN}Connected Clients:${NC}"
  grep "^CLIENT_LIST" /var/log/openvpn/status.log 2>/dev/null | while IFS=',' read -r _ user real virt _ _ _ since; do
    echo -e "  ${GREEN}▸${NC} ${user}  ${real} → ${virt}  since ${since}"
  done || echo -e "  ไม่มีข้อมูล"
  press_enter
}

# ═══════════════════════════════════════════════════
#  XRAY MENU
# ═══════════════════════════════════════════════════
xray_menu() {
  while true; do
    hdr
    local xstatus; xstatus=$(systemctl is-active x-ui 2>/dev/null || echo "inactive")
    echo -e "\n  ${YELLOW}════════════ Xray / 3x-ui ════════════${NC}"
    echo -e "  URL   : ${WHITE}https://${SSL_DOMAIN}:${XRAY_PORT}${NC}"
    echo -e "  User  : ${WHITE}${XRAY_USER}${NC}  Pass: ${WHITE}${XRAY_PASS}${NC}"
    echo -e "  Status: $([ "$xstatus" = "active" ] && echo "${GREEN}● กำลังทำงาน${NC}" || echo "${RED}○ หยุดทำงาน${NC}")"
    echo ""
    echo -e "  ${GREEN}1)${NC} ℹ️  แสดงข้อมูลการเชื่อมต่อ"
    echo -e "  ${GREEN}2)${NC} 🔄 Restart 3x-ui"
    echo -e "  ${GREEN}3)${NC} 📊 ดู Log 3x-ui"
    echo -e "  ${GREEN}0)${NC} ◀️  กลับ"
    echo ""
    mread ch "  ${WHITE}เลือก: ${NC}"
    case $ch in
      1)
        echo ""
        echo -e "  ${CYAN}Panel URL : ${WHITE}https://${SSL_DOMAIN}:${XRAY_PORT}${NC}"
        echo -e "  ${CYAN}Username  : ${WHITE}${XRAY_USER}${NC}"
        echo -e "  ${CYAN}Password  : ${WHITE}${XRAY_PASS}${NC}"
        echo -e "  ${CYAN}API Key   : ${WHITE}${API_KEY}${NC}"
        press_enter ;;
      2) systemctl restart x-ui && echo -e "  ${GREEN}✅ Restart แล้ว${NC}" || echo -e "  ${RED}ล้มเหลว${NC}"; sleep 1 ;;
      3) journalctl -u x-ui -n 30 --no-pager 2>/dev/null; press_enter ;;
      0) break ;;
    esac
  done
}

# ═══════════════════════════════════════════════════
#  SYSTEM STATUS
# ═══════════════════════════════════════════════════
sys_status() {
  hdr
  echo -e "\n  ${YELLOW}═════ สถานะระบบ ═════${NC}\n"
  local cpu; cpu=$(top -bn1 2>/dev/null | grep "Cpu(s)" | awk '{print $2}')
  local mu; mu=$(free -m | awk '/^Mem:/{print $3}')
  local mt; mt=$(free -m | awk '/^Mem:/{print $2}')
  local mp; mp=$(( mu * 100 / mt ))
  local du_info; du_info=$(df -h / | tail -1)
  local du; du=$(echo "$du_info" | awk '{print $3}')
  local dt; dt=$(echo "$du_info" | awk '{print $2}')
  local dp; dp=$(echo "$du_info" | awk '{print $5}')

  echo -e "  ${CYAN}🖥  CPU Usage   :${NC} ${cpu:-?}%"
  echo -e "  ${CYAN}💾 RAM Usage   :${NC} ${mu}MB / ${mt}MB (${mp}%)"
  echo -e "  ${CYAN}💿 Disk Usage  :${NC} ${du} / ${dt} (${dp})"
  echo -e "  ${CYAN}⏱  Uptime      :${NC} $(uptime -p 2>/dev/null | sed 's/up //')"
  echo -e "  ${CYAN}📅 Date/Time   :${NC} $(date '+%Y-%m-%d %H:%M:%S')"
  echo -e "  ${CYAN}🌐 WAN IP      :${NC} ${SERVER_IP}"

  echo -e "\n  ${YELLOW}═════ สถานะบริการ ═════${NC}\n"
  local svcs=(
    "vpn-panel:VPN Panel       "
    "ssh:SSH Server        "
    "ws-ssh:WS-SSH (8880)   "
    "openvpn@server:OpenVPN UDP     "
    "openvpn@server-tcp:OpenVPN TCP     "
    "ovpn-ws:OpenVPN WS(2086)"
    "stunnel4:OpenVPN SSL(2087)"
    "x-ui:3x-ui (Xray)   "
    "udpgw:UDP GW (7300)  "
    "ufw:Firewall (UFW)  "
    "fail2ban:Fail2ban        "
  )
  for entry in "${svcs[@]}"; do
    local svc="${entry%%:*}"; local label="${entry##*:}"
    local status; status=$(systemctl is-active "$svc" 2>/dev/null || echo "inactive")
    if [[ "$status" == "active" ]]; then
      echo -e "  ${GREEN}● ${label}${NC}: ${GREEN}กำลังทำงาน${NC}"
    else
      echo -e "  ${RED}○ ${label}${NC}: ${RED}หยุดทำงาน${NC}"
    fi
  done
  echo ""
  echo -e "  ${CYAN}🔗 SSH Connections :${NC} $(ss -tnp 2>/dev/null | grep ':22 ' | grep -c ESTAB || echo 0)"
  echo -e "  ${CYAN}🔗 OpenVPN Clients :${NC} $(grep -c '^CLIENT_LIST' /var/log/openvpn/status.log 2>/dev/null || echo 0)"
  press_enter
}

# ═══════════════════════════════════════════════════
#  SPEED TEST
# ═══════════════════════════════════════════════════
speed_menu() {
  while true; do
    hdr
    echo -e "\n  ${YELLOW}════════════ ทดสอบความเร็ว ════════════${NC}\n"
    echo -e "  ${GREEN}1)${NC} 🚀 speedtest-cli (ละเอียดสุด)"
    echo -e "  ${GREEN}2)${NC} ☁️  Cloudflare Speed Test"
    echo -e "  ${GREEN}3)${NC} 📡 Ping หลายปลายทาง"
    echo -e "  ${GREEN}4)${NC} 🌍 ข้อมูล IP & ISP"
    echo -e "  ${GREEN}0)${NC} ◀️  กลับ"
    echo ""
    mread ch "  ${WHITE}เลือก: ${NC}"
    case $ch in
      1)
        echo -e "\n  ${CYAN}กำลังทดสอบผ่าน Speedtest.net... (30-60 วินาที)${NC}\n"
        if command -v speedtest-cli &>/dev/null; then
          speedtest-cli --simple 2>/dev/null || echo "ล้มเหลว"
        else
          echo "ไม่พบ speedtest-cli กรุณาติดตั้ง: pip3 install speedtest-cli"
        fi
        press_enter ;;
      2)
        echo -e "\n  ${CYAN}ทดสอบผ่าน Cloudflare...${NC}\n"
        echo -n "  Download: "
        local dl; dl=$(curl -o /dev/null -s -w "%{speed_download}" --max-time 20 \
          "https://speed.cloudflare.com/__down?bytes=25000000" 2>/dev/null)
        echo "$(echo "scale=2; $dl*8/1000000" | bc) Mbps"
        press_enter ;;
      3)
        echo -e "\n  ${CYAN}กำลัง Ping...${NC}\n"
        for host in "8.8.8.8:Google DNS" "1.1.1.1:Cloudflare" "9.9.9.9:Quad9" "208.67.222.222:OpenDNS"; do
          local ip="${host%%:*}"; local name="${host##*:}"
          local ms; ms=$(ping -c 4 -W 2 "$ip" 2>/dev/null | tail -1 | awk -F'/' '{print $5}')
          printf "  %-15s %-20s %s ms\n" "$ip" "$name" "${ms:-timeout}"
        done
        press_enter ;;
      4)
        echo -e "\n  ${CYAN}ข้อมูล IP:${NC}\n"
        curl -s --max-time 5 "https://ipwho.is/" 2>/dev/null | python3 -c "
import json,sys
d=json.load(sys.stdin)
print(f'  IP      : {d.get(\"ip\",\"--\")}')
print(f'  Country : {d.get(\"country\",\"--\")}')
print(f'  City    : {d.get(\"city\",\"--\")}')
print(f'  ISP     : {d.get(\"connection\",{}).get(\"isp\",\"--\")}')
print(f'  ASN     : {d.get(\"connection\",{}).get(\"asn\",\"--\")}')
" 2>/dev/null || echo "  ไม่สามารถโหลดข้อมูลได้"
        press_enter ;;
      0) break ;;
    esac
  done
}

# ═══════════════════════════════════════════════════
#  SERVICE MANAGEMENT
# ═══════════════════════════════════════════════════
svc_menu() {
  while true; do
    hdr
    echo -e "\n  ${YELLOW}════════════ จัดการบริการ ════════════${NC}\n"
    local svcs=("vpn-panel" "ssh" "ws-ssh" "openvpn@server" "openvpn@server-tcp" "ovpn-ws" "stunnel4" "x-ui" "udpgw" "ufw" "fail2ban")
    local labels=("VPN Panel" "SSH" "WS-SSH" "OpenVPN-UDP" "OpenVPN-TCP" "OpenVPN-WS" "OpenVPN-SSL" "3x-ui" "UDP-GW" "UFW" "Fail2ban")
    local i=1
    for svc in "${svcs[@]}"; do
      local st; st=$(systemctl is-active "$svc" 2>/dev/null || echo "off")
      local badge; [[ "$st" == "active" ]] && badge="${GREEN}[ON]${NC}" || badge="${RED}[OFF]${NC}"
      printf "  ${CYAN}%d)${NC} %-12s %b\n" $i "${labels[$((i-1))]}" "$badge"
      ((i++))
    done
    echo ""
    echo -e "  ${CYAN}r)${NC} 🔄 Restart ทุกบริการ"
    echo -e "  ${CYAN}u)${NC} 📦 อัพเดต Panel"
    echo -e "  ${CYAN}0)${NC} ◀️  กลับ"
    echo ""
    mread ch "  ${WHITE}เลือก (หมายเลข/r/u/0): ${NC}"

    case $ch in
      [1-8])
        local idx=$((ch-1))
        local svc="${svcs[$idx]}"
        echo -e "\n  ${CYAN}1) Start  2) Stop  3) Restart  4) Status${NC}"
        mread act "  เลือก: "
        case $act in
          1) systemctl start "$svc" && echo -e "${GREEN}✅ Start ${svc}${NC}" ;;
          2) [[ "$svc" == "vpn-panel" ]] && echo "ไม่สามารถหยุด Panel ได้" || (systemctl stop "$svc" && echo -e "${GREEN}✅ Stop ${svc}${NC}") ;;
          3) systemctl restart "$svc" && echo -e "${GREEN}✅ Restart ${svc}${NC}" ;;
          4) systemctl status "$svc" --no-pager | head -15 ;;
        esac
        sleep 1 ;;
      r)
        echo -e "\n  ${CYAN}Restart ทุกบริการ...${NC}"
        for svc in "${svcs[@]}"; do
          systemctl restart "$svc" 2>/dev/null && echo -e "  ${GREEN}✓${NC} ${svc}" || echo -e "  ${YELLOW}⚠${NC} ${svc}"
        done
        press_enter ;;
      u)
        echo -e "\n  ${CYAN}อัพเดต Node packages...${NC}"
        cd /opt/vpn-panel && npm update --production >> /dev/null 2>&1
        systemctl restart vpn-panel
        echo -e "  ${GREEN}✅ อัพเดตแล้ว${NC}"
        press_enter ;;
      0) break ;;
    esac
  done
}

# ═══════════════════════════════════════════════════
#  LOG MENU
# ═══════════════════════════════════════════════════
log_menu() {
  while true; do
    hdr
    echo -e "\n  ${YELLOW}════════════ Log ระบบ ════════════${NC}\n"
    echo -e "  ${GREEN}1)${NC} Panel Log (vpn-panel service)"
    echo -e "  ${GREEN}2)${NC} Log การติดตั้ง"
    echo -e "  ${GREEN}3)${NC} OpenVPN Log"
    echo -e "  ${GREEN}4)${NC} Auth Log (SSH login)"
    echo -e "  ${GREEN}5)${NC} Fail2ban Log"
    echo -e "  ${GREEN}6)${NC} System Log (syslog)"
    echo -e "  ${GREEN}7)${NC} 3x-ui Log"
    echo -e "  ${GREEN}0)${NC} ◀️  กลับ"
    echo ""
    mread ch "  ${WHITE}เลือก: ${NC}"
    case $ch in
      1) journalctl -u vpn-panel -n 50 --no-pager; press_enter ;;
      2) tail -100 /var/log/vpn-panel-install.log 2>/dev/null | less; ;;
      3) tail -50 /var/log/openvpn/openvpn.log 2>/dev/null; press_enter ;;
      4) tail -50 /var/log/auth.log 2>/dev/null; press_enter ;;
      5) tail -50 /var/log/fail2ban.log 2>/dev/null; press_enter ;;
      6) tail -50 /var/log/syslog 2>/dev/null; press_enter ;;
      7) journalctl -u x-ui -n 50 --no-pager 2>/dev/null; press_enter ;;
      0) break ;;
    esac
  done
}

# ═══════════════════════════════════════════════════
#  CONNECTION INFO
# ═══════════════════════════════════════════════════
conn_info() {
  hdr
  echo -e "\n  ${YELLOW}════════════ ข้อมูลการเชื่อมต่อทั้งหมด ════════════${NC}\n"
  echo -e "  ${CYAN}🌐 VPN Panel${NC}"
  echo -e "     URL      : ${WHITE}https://${SSL_DOMAIN}:${PANEL_PORT}${NC}"
  echo -e "     Username : ${WHITE}${ADMIN_USER}${NC}"
  echo ""
  echo -e "  ${CYAN}⚡ 3x-ui (Xray)${NC}"
  echo -e "     URL      : ${WHITE}https://${SSL_DOMAIN}:${XRAY_PORT}${NC}"
  echo -e "     Username : ${WHITE}${XRAY_USER}${NC}"
  echo -e "     Password : ${WHITE}${XRAY_PASS}${NC}"
  echo ""
  echo -e "  ${CYAN}🔑 SSH Tunnel${NC}"
  echo -e "     Host     : ${WHITE}${SERVER_IP}${NC}"
  echo -e "     Port     : ${WHITE}22${NC}"
  echo -e "     WS Port  : ${WHITE}8880${NC}"
  echo -e "     WS URL   : ${WHITE}ws://${SERVER_IP}:8880${NC}"
  echo ""
  echo -e "  ${CYAN}🔒 OpenVPN${NC}"
  echo -e "     UDP      : ${WHITE}1194${NC}  (cert + user/pass)"
  echo -e "     TCP      : ${WHITE}1195${NC}  (cert + user/pass)"
  echo -e "     WebSocket: ${WHITE}2086${NC}  (HTTP Injector / HTTP Custom)"
  echo -e "     SSL/TLS  : ${WHITE}2087${NC}  (stunnel, bypass firewall)"
  echo ""
  echo -e "  ${CYAN}📡 UDP Gateway${NC}"
  echo -e "     Port     : ${WHITE}7300${NC}"
  echo ""
  echo -e "  ${CYAN}🔑 API Key${NC}"
  echo -e "     ${WHITE}${API_KEY}${NC}"
  echo ""
  echo -e "  ${MAGENTA}💾 ข้อมูลเต็ม: /etc/vpn-panel/install-info.txt${NC}"
  press_enter
}

# ═══════════════════════════════════════════════════
#  BACKUP
# ═══════════════════════════════════════════════════
backup_menu() {
  while true; do
    hdr
    echo -e "\n  ${YELLOW}════════════ สำรองข้อมูล ════════════${NC}\n"
    echo -e "  ${GREEN}1)${NC} 💾 สำรองข้อมูลทั้งหมด"
    echo -e "  ${GREEN}2)${NC} 📁 สำรอง Config เท่านั้น"
    echo -e "  ${GREEN}3)${NC} 👥 สำรอง Client Files"
    echo -e "  ${GREEN}4)${NC} 📋 ดูรายการ Backup"
    echo -e "  ${GREEN}0)${NC} ◀️  กลับ"
    echo ""
    mread ch "  ${WHITE}เลือก: ${NC}"
    local BDIR="/root/vpn-backups"
    local DATE; DATE=$(date +%Y%m%d_%H%M%S)
    mkdir -p "$BDIR"
    case $ch in
      1)
        local OUT="${BDIR}/full_${DATE}.tar.gz"
        tar -czf "$OUT" /opt/vpn-panel/config /opt/vpn-panel/clients /etc/vpn-panel /etc/openvpn 2>/dev/null
        echo -e "  ${GREEN}✅ ${OUT}${NC}"
        press_enter ;;
      2)
        local OUT="${BDIR}/config_${DATE}.tar.gz"
        tar -czf "$OUT" /opt/vpn-panel/config /etc/vpn-panel 2>/dev/null
        echo -e "  ${GREEN}✅ ${OUT}${NC}"
        press_enter ;;
      3)
        local OUT="${BDIR}/clients_${DATE}.tar.gz"
        tar -czf "$OUT" /opt/vpn-panel/clients 2>/dev/null
        echo -e "  ${GREEN}✅ ${OUT}${NC}"
        press_enter ;;
      4)
        ls -lh "$BDIR"/ 2>/dev/null | tail -10 || echo "ไม่มี Backup"
        press_enter ;;
      0) break ;;
    esac
  done
}

# ── MAIN ──────────────────────────────────────────
load_cfg
main_menu
